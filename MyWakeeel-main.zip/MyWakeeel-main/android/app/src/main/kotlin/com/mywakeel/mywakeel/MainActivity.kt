package com.mywakeel.mywakeel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
