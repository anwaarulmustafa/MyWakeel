import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  setupLocator();
  runApp(MyApp() );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MyWakeel',
      theme: ThemeData(  
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          textTheme: TextTheme(
            headline6: TextStyle(
              color: appColor,
              fontSize: 22
              )
          ),
          iconTheme: IconThemeData(
            color: appColor
          )
          ),    
        primaryColor: appColor, 
              
      ),
      onGenerateRoute: StackedRouter().onGenerateRoute,
      navigatorKey: StackedService.navigatorKey
    );
  }
}

