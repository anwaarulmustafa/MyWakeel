import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/views/profile/viewprofile_view/viewprofile_view.dart';
import 'const_size.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:transparent_image/transparent_image.dart';


const Color appColor = Colors.green;
const String appIcon = 'assets/images/icon.png';

List<String> dropDownGender = ['Male', 'Female'];

Widget customLoader(){
  return Center(child: CircularProgressIndicator(valueColor: new AlwaysStoppedAnimation<Color>(appColor),));
                
}


Widget iconHeader(context, double scale){
  return 
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: MySize.xMargin(context, scale),
                        width: MySize.xMargin(context, scale),
                        child: Image(image: AssetImage(appIcon))),
                        
               SizedBox(
              width:5
              ),
                        Text('MyWakeel',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: MySize.textSize(context, scale/1.6),
                    fontWeight: FontWeight.bold,
                  ),
                  ),
                    ],
                  );
}

Widget iconOnly(context, double scale){
  return Container(
                    height: MySize.xMargin(context, scale),
                    width: MySize.xMargin(context, scale),
                    child: Image(image: AssetImage(appIcon)));
}
Widget minHeight(context){
  return SizedBox(height: MySize.yMargin(context, 1),);

}
Widget smallHeight(context){
  return SizedBox(height: MySize.yMargin(context, 2),);

}

Widget mediumHeight(context){
  return SizedBox(height: MySize.yMargin(context, 10),);

}
Widget smallWidth(context){
  return SizedBox(width: MySize.xMargin(context, 3),);

}

Widget mediumWidth(context){
  return SizedBox(width: MySize.xMargin(context, 10),);

}
Widget customTextField({TextEditingController? controller, int? maxLines, TextInputType? keyboardType, TextInputAction? textInputAction, bool? isEnabled,hintText}){
  return  Card(
                  child: TextFormField(
                    controller: controller,
                    maxLines: maxLines,
                    enabled: isEnabled,
                    keyboardType: keyboardType,
                    textInputAction: textInputAction,
                    validator: (value) =>validator(value!),
                    
                    
                    decoration: InputDecoration(
                      labelText: hintText,
                      contentPadding: EdgeInsets.all(12),
                      
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: appColor)

                      ),
                       border: InputBorder.none,
                    ),

                    
                  ),
                );
}

Widget customButton(context, { String? text, Function? onPressed}){
  return Center(
    child: Container(
                  width: MySize  .xMargin(context, 50),
                  height: 50,
                  child: OutlinedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(appColor),
                      shape:  MaterialStateProperty.all(RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)))
                    ),
                    
                    onPressed: onPressed as Function(),
                    child: Center(child: Text(text!, style: TextStyle(
                      color: Colors.white,
                      fontSize: MySize.textSize(context, 4.5),
                      ),)),

                  ),
                ),
  );

}

Widget customItem(UserDetails user, context){
    return InkWell(
      onTap: (){
        Navigator.of(context).push(CupertinoPageRoute(builder: (context)=>ViewProfileView(details: user)));



      },
      child: Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: Card(
                          child: Container(
                            height: MySize.yMargin(context, 35),
                            width: MySize.xMargin(context, 45),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child:
                                  user.imageUrl !=null? 
                                  FadeInImage.memoryNetwork(
                                    placeholder: kTransparentImage, 
                                    image: user.imageUrl!, fit: BoxFit.cover,):
                                  Image(image: AssetImage(appIcon),fit: BoxFit.cover,)
                                  
                                  ),
                                
                Expanded(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('${user.name}',
                                     style: TextStyle(
                                       fontWeight: FontWeight.bold,
                                       fontSize: MySize.textSize(context, 4.5),),),
                    ),
                  ),
                ),


                            ],),
                          ),
                        ),
                      ),
    );
  }

  customDropDown( String text, Function? onChanged){
      return Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: DropdownButton<String>(
                  isExpanded: true,
                  underline: Container(),
                  hint: Text(text),
                  items: dropDownGender.map((e) =>  DropdownMenuItem<String>(
                  value: e,
                    child: Text(e),)
                   ).toList(),
                   onChanged: onChanged as Function(String?) ,
                ),
              ),
            );
  }

  validator( String text){
    if(text.length == 0||text.isEmpty){
      return 'Field cannot be empty';
    }
    return null;
  }


 Future<void> showLoadingDialog(BuildContext context, GlobalKey key) async{
    return showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context){
        return new WillPopScope(
          onWillPop: () async => false,
          child: SimpleDialog(
            key: key,
            backgroundColor: Colors.white,
            children: <Widget>[
              Center(child: Column(children: <Widget>[
                CircularProgressIndicator(valueColor: new AlwaysStoppedAnimation<Color>(appColor),),
                SizedBox(height: 10,),
                Text('Please wait...', style: TextStyle(color: appColor),)
              ],),)
            ],
          ),
        );
      }

    );
  }

  Future<void> showLoadingDialogWithText(BuildContext context, GlobalKey key, String text) async{
    return showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context){
        return new WillPopScope(
          onWillPop: () async => false,
          child: SimpleDialog(
            key: key,
            backgroundColor: Colors.white,
            children: <Widget>[
              Center(child: Column(children: <Widget>[
                CircularProgressIndicator(valueColor: new AlwaysStoppedAnimation<Color>(appColor),),
                SizedBox(height: 10,),
                Text('$text Please wait... ', style: TextStyle(color: appColor),)
              ],),)
            ],
          ),
        );
      }

    );
  }

  Widget showBusy(model){
    return Visibility(
                  visible: model.isBusy,
                  child: 
                 CircularProgressIndicator(
                   valueColor: AlwaysStoppedAnimation<Color>(appColor),
                 ));
  }

  Widget searchItem (UserDetails user, context){
    return InkWell(
                onTap: (){
                 Navigator.of(context).push(CupertinoPageRoute(builder: (context)=>ViewProfileView(details: user)));

                },
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                           Container(
                                height: MySize.xMargin(context, 15),
                                width: MySize.xMargin(context, 15),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50),
                                  image:  user.imageUrl !=null?
                                   DecorationImage(
                                     fit: BoxFit.cover,
                                    image: 
                                    NetworkImage(user.imageUrl!),
                                  ): 
                                   DecorationImage(
                                     fit: BoxFit.cover,
                                    image: AssetImage("assets/images/icon.png",),
                                  ),
                                    ),
                              ),
                         
                          smallWidth(context),
                          Text(
                            '${user.name}',
                            style: TextStyle(
                              fontSize: MySize.textSize(context, 7),
                            ),
                          )
                        ],
                      ),
                    ),
                  Divider(),
                  ],
                ),
              );
  }

class ExpandableContainer extends StatefulWidget {
  final bool? isExpanded;
  final Widget? collapsedchild, expandedChild;
  ExpandableContainer({this.isExpanded, this.collapsedchild, this.expandedChild});
  

  @override
  _ExpandableContainerState createState() => _ExpandableContainerState();
}

class _ExpandableContainerState extends State<ExpandableContainer> {

  @override
  Widget build(BuildContext context) {
    
    return AnimatedContainer(
      duration: Duration(milliseconds: 200),
      curve: Curves.easeInOut,
      child: widget.isExpanded! ?widget.expandedChild : widget.collapsedchild,
    );
  }
}