import 'package:intl/intl.dart';
import 'dart:developer';

/*
      Lat        Long
main      7.7148867  5.2510939
0.15km      7.7148900  5.2524400
5.6km      7.7550000  5.2820000
8.79km      7.7850000  5.2880000
9.09km      7.7880000  5.2880000
10.59km      7.7980000  5.2980000
// 10.59km      7.7990000  5.2990000
10.59km      7.8200000  5.2990000
13.94km      7.8200000  5.3200000
21.97km      7.8200000  5.4200000
 */
String googleApi = 'AIzaSyDCvFZy58NTZY-SLSICiw9SMn29KgK1-3E';

String formatDate(String timeStamp) {
  var old = DateTime.parse(timeStamp);
  var now = DateTime.now();
  String time = '';
  var diff = now.difference(old);

  if (diff.inDays <= 1) {
    time = 'Today';
  } else if (diff.inDays > 1 && diff.inDays < 2) {
    time = 'Yesterday';
  } else {
    time = DateFormat('yyyy/MM/dd ').format(old);
  }
  log('$time');
  return time;
}

String formatTime(String timeStamp) {
  var old = DateTime.parse(timeStamp);
  var format = DateFormat('HH:mm a').format(old);

  log('$format');
  return format;
}

DateTime readFromString(String timeStamp) {
  return DateTime.parse(timeStamp);
}
