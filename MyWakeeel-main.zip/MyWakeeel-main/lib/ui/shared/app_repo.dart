import 'package:firebase_auth/firebase_auth.dart';
import 'package:mywakeel/models/user_details.dart';

class AppRepo{
  static UserDetails? currentUserDetails;
  static User? firebaseCurrentUser;
  static bool? isLawyer;
}