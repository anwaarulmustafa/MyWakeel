import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:intl/intl.dart';
import 'package:mywakeel/models/feed_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/views/home_view/lawyersfeed_view/lawyersfeedcomments_view.dart';

class FeedCard extends StatefulWidget {
  const FeedCard({
    Key? key,
    required this.feed,
     this.onLikeTapped, this.onCommentTapped,
  }) : super(key: key);

  final FeedDetails feed;
  final Function? onLikeTapped, onCommentTapped;

  @override
  _FeedCardState createState() => _FeedCardState();
}

class _FeedCardState extends State<FeedCard> {
  bool isLiked = false;
  int noOfLikes =0, nofComments=0;
  @override
    void initState() {
      isLiked = widget.feed.likedBy!.contains(AppRepo.currentUserDetails!.uid);
      noOfLikes =widget.feed.likedBy!.length;
      nofComments = widget.feed.noOfComments!;

      super.initState();
    }

    updateLikes() async {
      setState(() {
        if(isLiked ==true){
        isLiked =false;
        noOfLikes -=1;
      }else{
        isLiked =true;
        noOfLikes +=1;

      }});
      // widget.onLikeTapped!();
   await FirebaseService().likePostComment(widget.feed);
      

    }

  
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    widget.feed.posterImageUrl!=null?
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        shape: BoxShape.circle,
                        
                      ),
                      child:FadeInImage(placeholder: AssetImage(appIcon),
                       image: NetworkImage(widget.feed.posterImageUrl!))
                    ):CircleAvatar(
                      radius: 16,backgroundImage:AssetImage(appIcon),
                    ),
                    smallWidth(context),
                    Text(
                      widget.feed.posterName!,
                      style: TextStyle(
                          fontSize: MySize.textSize(context, 6),
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                Text(
                  DateFormat.jm().format(DateTime.parse(widget.feed.date!)),
                  style: TextStyle(fontSize: MySize.textSize(context, 4.5)),
                ),
              ],
            ),
            smallHeight(context),
            Padding(
              padding: const EdgeInsets.only(left: 45.0),
              child: Text(
                widget.feed.postText!,
                style: TextStyle(fontSize: MySize.textSize(context, 4.5)),
              ),
            ),
            Visibility(
              visible:  widget.feed.containsImage!,
              child: Container(
                    margin: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child:  FadeInImage(
                      placeholder: AssetImage(appIcon), 
                      image: NetworkImage(widget.feed.postMedia!,),),)),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
               
                   Row(
              children: [
                IconButton(
                  onPressed: updateLikes,
                  iconSize: 30,
                  icon: Icon(isLiked?Icons.favorite:Icons.favorite_border, color: appColor),
                  ),
                  Text('$noOfLikes', style: TextStyle(
                    fontSize: MySize.textSize(context, 4)
                  ),) ,
              ],
            ),
            smallWidth(context),
             Row(
              children: [
                IconButton(
                  onPressed: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context)=>LawyerCommentView(widget.feed)));
                    // widget.onCommentTapped!();
                  },
                  iconSize: 30,
                  icon: Icon(FontAwesome5.comment_alt, color: appColor)
                  ),
                  Text('$nofComments', style: TextStyle(
                    fontSize: MySize.textSize(context, 4)
                  ),) ,
              ],
            )
              
              
              
              ],
            ),
           
            ],
        ),
      ),
    );
  }
}