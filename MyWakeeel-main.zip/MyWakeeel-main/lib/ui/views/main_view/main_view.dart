import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/views/home_view/home_view.dart';
import 'package:mywakeel/ui/views/main_view/main_viewmodel.dart';
import 'package:mywakeel/ui/views/messages/message_view/message_view.dart';
import 'package:mywakeel/ui/views/notifications_view/notifications_view.dart';
import 'package:mywakeel/ui/views/profile/profile_view/profile_view.dart';
import 'package:mywakeel/ui/views/search/search_view/search_view.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter_icons/flutter_icons.dart';

class MainView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<MainViewModel>.reactive(
        builder: (context, model, child) {
          return Scaffold(
            body: navigationItems(model.currentIndex),
            bottomNavigationBar: BottomNavigationBar(
              showSelectedLabels: false,
              showUnselectedLabels: false,
              type: BottomNavigationBarType.fixed,
              currentIndex: model.currentIndex,
              onTap: model.onTap,
              items: [
                BottomNavigationBarItem(
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 1),
                      child: Icon(FlutterIcons.home_ant),
                    ),
                    label: 'Home'),
                BottomNavigationBarItem(
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 1),
                      child: Icon(FlutterIcons.mail_ant),
                    ),
                    label: 'Message'),
                BottomNavigationBarItem(
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 1),
                      child: Icon(FlutterIcons.search1_ant),
                    ),
                    label: 'Search'),
                BottomNavigationBarItem(
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 1),
                      child: Icon(FlutterIcons.ios_notifications_outline_ion),
                    ),
                    label: 'Notifications'),
                BottomNavigationBarItem(
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 1),
                      child: Icon(FlutterIcons.person_outline_mdi),
                    ),
                    label: 'Profile'),
              ],
            ),
          );
        },
        viewModelBuilder: () => MainViewModel());
  }

  navigationItems(int index) {
    switch (index) {
      case 0:
        if (AppRepo.isLawyer!) {
          return LawyerHomeView();
        } else {
          return ClientHomeView();
        }
      //  HomeView();
      case 1:
        return MessageView();
      case 2:
        return SearchView();
      case 3:
        return NotificationsView();
      case 4:
        return ProfileView();
    }
  }
}
