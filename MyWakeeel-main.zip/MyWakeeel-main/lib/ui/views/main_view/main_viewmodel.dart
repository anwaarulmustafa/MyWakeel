import 'package:stacked/stacked.dart';

class MainViewModel extends BaseViewModel{
   int currentIndex = 0;
   
   onTap(index){
     currentIndex = index;
     notifyListeners();
   }

  
}