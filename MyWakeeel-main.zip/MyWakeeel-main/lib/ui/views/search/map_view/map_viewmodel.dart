import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:mywakeel/ui/shared/location.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
// import 'package:google_maps_flutter_web/google_maps_flutter_web.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/views/profile/viewprofile_view/viewprofile_view.dart';
import 'package:mywakeel/services/firebase_service.dart';

class MapViewModel extends BaseViewModel{
  Set<Marker> markers = {};
  Map<MarkerId,Marker> marker = {};
   List<UserDetails> userDetails =[];  
   List<UserDetails> courtDetails =[];
   List<UserDetails> cityDetails =[];
   List<UserDetails> allUsers =[];
   late double currentLat, currentLong;
  FirebaseService _firebaseService = locator<FirebaseService>();
 CameraTargetBounds? bounds;
  Completer<GoogleMapController> controller = Completer();

  Set<Circle> circles = Set.from([Circle(
    circleId: CircleId('id'),
    center: LatLng(double.parse('7.7188321'), double.parse('7.7188321')),
    radius: 4000,
)]);

 CameraPosition myLocation =
  CameraPosition(
    target: LatLng(double.parse('7.7188321'), 
    double.parse('7.7188321')),
    zoom: 11.0
    );

updateLocation() async {
  final pos = await determinePosition();
   currentLat = pos.latitude;
   currentLong = pos.longitude;
   final latlng = LatLng(currentLat, currentLong);
   myLocation=
  CameraPosition(
    target: latlng,
    zoom: 12.0
    );
    circles = Set.from([Circle(
      fillColor: Colors.blue.withOpacity(0.25),
      strokeColor: Colors.blue.withOpacity(0.3),
      strokeWidth: 2,
    circleId: CircleId('id'),
    center: latlng,
    radius: 4000,
)]);

  notifyListeners();
    

}
  
 searchUserLocation(context) async{
   setBusy(true);
   notifyListeners();
   updateLocation();
     userDetails = await _firebaseService.searchLawyers();
     userDetails.forEach((user) async{
       final getDiatsnce =  Geolocator
       .distanceBetween(currentLat, currentLong,
        double.parse(user.lat!), double.parse(user.long!));
        final d = NumberFormat.compact().format(getDiatsnce/1000);
       markers.add(Marker(
      markerId: MarkerId(user.uid!),
      position: LatLng(double.parse(user.lat!),double.parse(user.long!)),
        infoWindow: InfoWindow(
            title: user.name, snippet: '$d KM away'),
        onTap: () {
           Navigator.of(context)
           .push(CupertinoPageRoute(
             builder: (context)=>ViewProfileView(details: user)));


        },
      ));
       
     });
     
   setBusy(false);
   notifyListeners();

  }

  filterUserLocation(context) async{
   updateLocation();
    // bounds = CameraTargetBounds(
    //   LatLngBounds(northeast: LatLng(latitude, longitude),
    //   southwest: LatLng(latitude, longitude),),
    // );
     userDetails.forEach((user) {
       markers.add(Marker(
      markerId: MarkerId(user.uid!),
      position: LatLng(double.parse(user.lat!),double.parse(user.long!)),
        infoWindow: InfoWindow(
            title: user.name, snippet: user.name),
        onTap: () {
           Navigator.of(context)
           .push(MaterialPageRoute(
             builder: (context)=>ViewProfileView(details: user)));


        },
      ));
       
     });

  }
  getDistance(){
//     final R = 6378.1;
//     final brng =1.57;
//     final d = 15;
// math.
    // final lat1 = acos(d);
  }

}