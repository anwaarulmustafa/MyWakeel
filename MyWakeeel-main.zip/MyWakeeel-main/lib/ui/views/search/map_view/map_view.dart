import 'package:flutter/material.dart';

import 'package:flutter/cupertino.dart';
// import 'package:google_maps_flutter_web/google_maps_flutter_web.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'map_viewmodel.dart';

class MapView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<MapViewModel>.reactive(
      builder: (context, model, child){
      return Scaffold(
       appBar: AppBar(
            iconTheme: IconThemeData(color: Colors.white),
            backgroundColor: appColor,
            title: Text(
              "Lawayers around you",
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        body:
                      Visibility(
                        visible: !model.isBusy,
                        replacement: customLoader(),
                        child: GoogleMap(
                        
    initialCameraPosition: model.myLocation,
    circles: model.circles,
    mapType: MapType.normal,
     myLocationEnabled: true,
    myLocationButtonEnabled: true,
    zoomGesturesEnabled: true,
    markers: model.markers,
    onMapCreated: (GoogleMapController controller) {
      model.controller.complete(controller);
    },
    onCameraMove: (CameraPosition position){
      
    },
  ),
                      ),
                  // ),
          // Container(
          //   height: MySize.yMargin(context, 8),
          //   child: ListView(
          //     scrollDirection: Axis.horizontal,
          //     children: [
          //       Card(
          //         color: appColor,
          //         shape: RoundedRectangleBorder(
          //             borderRadius: BorderRadius.circular(20)),
          //         child: Center(
          //           child: Padding(
          //             padding:
          //                 const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          //             child: Text(
          //               '5-10km',
          //               style: TextStyle(
          //                 color: Colors.white,
          //                 fontSize: MySize.textSize(context, 5),
          //               ),
          //             ),
          //           ),
          //         ),
          //       ),
          //       Card(
          //         color: appColor,
          //         shape: RoundedRectangleBorder(
          //             borderRadius: BorderRadius.circular(20)),
          //         child: Center(
          //           child: Padding(
          //             padding:
          //                 const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          //             child: Text(
          //               '5-10km',
          //               style: TextStyle(
          //                 color: Colors.white,
          //                 fontSize: MySize.textSize(context, 5),
          //               ),
          //             ),
          //           ),
          //         ),
          //       ),
          //       Card(
          //         color: appColor,
          //         shape: RoundedRectangleBorder(
          //             borderRadius: BorderRadius.circular(20)),
          //         child: Center(
          //           child: Padding(
          //             padding:
          //                 const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          //             child: Text(
          //               '5-10km',
          //               style: TextStyle(
          //                 color: Colors.white,
          //                 fontSize: MySize.textSize(context, 5),
          //               ),
          //             ),
          //           ),
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
    //   ],
    // ),
        // ),
      );
    },
      onModelReady: (model){
        model.searchUserLocation(context);

      }, viewModelBuilder: ()=>MapViewModel());
  }
}