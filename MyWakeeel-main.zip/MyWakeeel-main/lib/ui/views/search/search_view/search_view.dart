import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:stacked/stacked.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'search_viewmodel.dart';

class SearchView extends StatelessWidget {
  
  final PageStorageBucket bucket = PageStorageBucket();

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SearchViewModel>.reactive(
      builder: (context, model, child) {
        return DefaultTabController(
          length: 4,
          initialIndex: model.currentTab,
          child: Scaffold(
            body: SafeArea(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: MySize.yMargin(context, 6),
                      decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(20)),
                      child: TextField(
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            prefixIcon: Icon(Icons.search),
                            hintText: 'Search'),
                        textInputAction: TextInputAction.go,
                        onSubmitted:(value) {
                          model.searchUser(value);
                        },
                      ),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.0),
                        border: Border(
                            bottom:
                                BorderSide(color: Colors.grey, width: 0.8))),
                    child: TabBar(
                      indicatorColor: appColor,
                      indicatorWeight: 3.0,
                      labelColor: Colors.black,
                      tabs: <Widget>[
                        Tab(
                          child: Container(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text('Name'),
                            ),
                          ),
                        ),
                        Tab(
                          child: Container(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text('Court'),
                            ),
                          ),
                        ),
                        Tab(
                          child: Container(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text('City'),
                            ),
                          ),
                        ),
                        Tab(
                          child: Container(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text('Location'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      child: TabBarView(
                        children: [
                          NameScreen(model),
                          CourtScreen(model),
                          CityScreen(model),
                          Location(model),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
      viewModelBuilder: () => SearchViewModel(),
    );
  }
}

class NameScreen extends StatelessWidget {
  final SearchViewModel model;
  NameScreen(this.model);

  @override
  Widget build(BuildContext context) {
    return Visibility(
        visible: model.userDetails.length != 0,
        replacement: Container(),
        child: ListView.builder(
            itemCount: model.userDetails.length,
            itemBuilder: (context, index) {
              final user = model.userDetails[index];

              return searchItem(user, context);
            }));
  }
}

class CourtScreen extends StatelessWidget {
  final SearchViewModel model;
  CourtScreen(this.model);

  @override
  Widget build(BuildContext context) {
    return Visibility(
        visible: model.courtDetails.length != 0,
        replacement: Container(),
        child: ListView.builder(
            itemCount: model.courtDetails.length,
            itemBuilder: (context, index) {
              final user = model.courtDetails[index];

              return searchItem(user, context);
            }));
  }
}

class CityScreen extends StatelessWidget {
  final SearchViewModel model;
  CityScreen(this.model);

  @override
  Widget build(BuildContext context) {
    return Visibility(
        visible: model.cityDetails.length != 0,
        replacement: Container(),
        child: ListView.builder(
            itemCount: model.cityDetails.length,
            itemBuilder: (context, index) {
              final user =model.cityDetails[index];

              return searchItem(user, context);
            }));
  }
}


class Location extends StatelessWidget {
  final SearchViewModel model;
  Location(this.model);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(
        height: MySize.yMargin(context, 10),
        child: InkWell(
                              onTap: model.navigateToMap,
                              child:Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  children: [
                                    Icon(Icons.location_on, size:MySize.xMargin(context, 10)),
                                    smallWidth(context),
                                    Text('Search Nearby Lawyers',style: TextStyle(
                                      fontSize: MySize.textSize(context, 5)
                                    ),),
                                  ],
                                ),
                              ),
                            ),
      ),
      
    );
  }
}
