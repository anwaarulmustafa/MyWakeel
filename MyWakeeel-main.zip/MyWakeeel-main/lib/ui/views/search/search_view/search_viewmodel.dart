
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:stacked/stacked.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:stacked_services/stacked_services.dart';

class SearchViewModel extends BaseViewModel{
  int currentTab = 0;
  NavigationService _navigationService = locator<NavigationService>();

   List<UserDetails> userDetails =[];  
   List<UserDetails> courtDetails =[];
   List<UserDetails> cityDetails =[];
   List<UserDetails> allUsers =[];
  FirebaseService _firebaseService = locator<FirebaseService>();
  
  
   searchUser(String searchTerm) async{
        allUsers = await _firebaseService.searchLawyers();
        allUsers.forEach((element) {
          if(element.name!.toLowerCase() ==searchTerm.toLowerCase() ){
            userDetails.add(element);

          }else if(element.city!.toLowerCase() ==searchTerm.toLowerCase()){
            cityDetails.add(element);
          }else if(element.court!.toLowerCase() ==searchTerm.toLowerCase() ){
            courtDetails.add(element);

          }
         });
     notifyListeners();
   }

   navigateToMap(){
     _navigationService.navigateTo(Routes.mapView);

   }

 


}