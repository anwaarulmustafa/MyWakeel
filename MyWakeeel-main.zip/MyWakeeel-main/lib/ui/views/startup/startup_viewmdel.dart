import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/foundation.dart';

import 'package:stacked_services/stacked_services.dart';

class StartUpViewModel extends BaseViewModel{
  NavigationService _navigationService = locator<NavigationService>();
  AuthenticationService _authenticationService = locator<AuthenticationService>();

  checkLogin() async{
     if(kIsWeb){
        _navigationService.clearStackAndShow(Routes.signInView);
     }else{
       final isLoggedin = await _authenticationService.isUserLoggedIn();
    if(isLoggedin){
       _navigationService.clearStackAndShow(Routes.mainView);

    }else{
      _navigationService.clearStackAndShow(Routes.authenticationUpView);
        }

     }
    
   

  }


  void navigateToSignIn() {
    _navigationService.navigateTo(Routes.signInView);
  }

  void navigateToSignUp() {
     _navigationService.navigateTo(Routes.mainSignUpView);
  }
}