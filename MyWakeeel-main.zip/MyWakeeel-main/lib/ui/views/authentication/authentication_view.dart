import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'authentication_viewmodel.dart';


class AuthenticationUpView extends StatelessWidget {
   AuthenticationUpView({Key? key}):super(key: key);
 
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AuthenticationUpViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
        body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               iconHeader(context, 10),
               Expanded(
                 child: 
                CarouselSlider(
                    items: model.list.entries.map((e) {
                      return  Builder(
                        builder: (context){
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              
                              children: [
                   Expanded(
                     flex: 2,
                 child: SvgPicture.asset('${e.value}')
               ),
               smallHeight(context),
               
                               Text('${e.key}',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 5),
                    color: Colors.grey[600]
                  ),
                  ),
                  
              
                              ],
                            ),
                          );
                        },
                      );
                    } ).toList(),
                  options: CarouselOptions(
                    autoPlay: true,
                    initialPage: 1,
                    onPageChanged: (index, reason){
                     final u = model.list.entries.elementAt(index);
                     model.updatePage(u.key);


                    },
                    
                    enableInfiniteScroll: false
                  ) ,),
                  
               ),
                smallHeight(context),
                  Row(mainAxisAlignment:MainAxisAlignment.center,
                  children: model.list.entries.map((val){
                    final key = val.key;
                    return Container(
                      width: 8,
                      height: 8,
                      margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: model.currentPage==key?
                        appColor:
                        Color.fromRGBO(0, 0, 0, 0.2),
                      ),
                    );
                  }).toList(),
                  ),

               smallHeight(context),
              Row(
                children: [
                  button('Sign Up',appColor,Colors.white, context, 
                  onPressed: ()=>model.navigateToSignUp()),
                  

              SizedBox(
                width:10,
              ),
              
                button('Sign In',Colors.white, appColor, context, 
                onPressed:()=> model.navigateToSignIn()),

            

              ],),

            
            ]
          ),
        ),
        ),


      );
      }, 
      viewModelBuilder: ()=>AuthenticationUpViewModel());
      
    
  }

  Widget button(String text,Color backColor,Color textColor, context,{Function? onPressed}){
    return  Expanded(
                    child: Container(
                height: 50,
                child: OutlinedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(backColor),
                      shape:  MaterialStateProperty.all(RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30)))
                    ),
                    
                    onPressed: onPressed as Function(),
                    child: Center(child: Text(text,
                   
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 4.5),
                      color: textColor),)),

                ),
              ),
                  );
  }
}