import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/cupertino.dart';
import 'signin_viewmodel.dart';

class SignInView extends StatelessWidget {
  final email = TextEditingController();
  final password = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final webformKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SignInViewModel>.reactive(
      builder: (context, model, child) {
          return Scaffold(
            key: scaffoldKey,
            body: kIsWeb? _buildWebView(model, context):
             _buildMobileView(model, context));
      },
      viewModelBuilder: () => SignInViewModel(),
    );
  }

  Widget _buildMobileView(SignInViewModel model, BuildContext context) {
    return SafeArea(
          child: SingleChildScrollView(
            child: Form(
              key: formKey,
                child: Padding(
        padding: const EdgeInsets.all(8.0),
        child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconButton(
              icon: Icon(Icons.arrow_back_ios),
              onPressed: model.goBack,
            ),
            smallHeight(context),
            iconHeader(context, 14),
            mediumHeight(context),
            Text(
              'Login to your account',
              style: TextStyle(
                  fontSize: MySize.textSize(context, 6),
                  fontWeight: FontWeight.bold,
                  color: appColor),
            ),
            smallHeight(context),
            customTextField(hintText: 'Email', controller: email,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,),
            customTextField(hintText: 'Password', controller: password),
            smallHeight(context),
            Align(
              alignment: Alignment.centerRight,
              child: InkWell(
                onTap: model.navigateToForgotPassword,
                child: Text(
                  'Forgot Password?',
                  style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                      fontWeight: FontWeight.w400),
                ),
              ),
            ),
            smallHeight(context),
            smallHeight(context),
            customButton(context, text: 'Sign in', onPressed: (){
             if(formKey.currentState!.validate()){
                 model.signIn(email.text, password.text, context, scaffoldKey);
              }
                       }),
            smallHeight(context),
            SizedBox(
              height: 20,
            ),
            Center(
              child: InkWell(
                onTap: model.navigateToSignUp,
                child: Text(
                  'Create Account',
                  style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                      fontWeight: FontWeight.w400),
                ),
              ),
            ),
            // Spacer(),
        ]),
      )),
          ));
  }

  Widget _buildWebView(SignInViewModel model, BuildContext context) {
    return SafeArea(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
          width: MySize.xMargin(context, 50),
            color: appColor,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    Image.asset(
                      appIcon,
                      width: MySize.xMargin(context, 20),
                    ),
                    smallWidth(context),
                    Text(
                      'MyWakeel',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: MySize.textSize(context, 5.5),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            width: MySize.xMargin(context, 50),
            
            color: Colors.white,
            child: Form(
              key: webformKey,
              child: Padding(
                padding: const EdgeInsets.all(14.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    mediumHeight(context),
                    Text(
                      'Login to your account',
                      style: TextStyle(
                          fontSize: MySize.textSize(context, 6),
                          fontWeight: FontWeight.bold,
                          color: appColor),
                    ),
                    smallHeight(context),
                    customTextField(hintText: 'Email', controller: email),
                    customTextField(hintText: 'Password', controller: password),
                    smallHeight(context),
                    Align(
                      alignment: Alignment.centerRight,
                      child: InkWell(
                        onTap: ()=>model.navigateToForgotPassword(),
                        child: Text(
                          ' Forgot Password?',
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 4),
                              fontWeight: FontWeight.w400),
                        ),
                      ),
                    ),
                    smallHeight(context),
                    smallHeight(context),
                    customButton(context,
                        text: 'Sign in', onPressed: (){
                           if(webformKey.currentState!.validate()){
                 model.signIn(email.text, password.text, context, scaffoldKey);
              

            }
                       }),
                    smallHeight(context),
                    Center(
                      child: InkWell(
                        onTap: ()=> model.navigateToSignUp(),
                        child: Text(
                          'Create Account',
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 4),
                              fontWeight: FontWeight.w400),
                        ),
                      ),
                      ),  
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    ); 
  }
}
