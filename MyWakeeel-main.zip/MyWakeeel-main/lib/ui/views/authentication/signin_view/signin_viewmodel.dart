import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class SignInViewModel extends BaseViewModel{
   NavigationService _navigationService = locator<NavigationService>();
  AuthenticationService _authenticationService = locator<AuthenticationService>();
   
  goBack()=> _navigationService.back();

  navigateToForgotPassword(){
    _navigationService.navigateTo(Routes.forgotView);

  }

  Future signIn(String email, String password, context, scaffoldKey) async {
    
    final canLogin = await  _authenticationService
    .logInWithEmail(email: email, password: password,
     context:context, scaffoldKey: scaffoldKey);
    if(canLogin ==true){
      _navigationService.navigateTo(Routes.mainView);
    }

  
  }

  void navigateToSignUp() {
       _navigationService.navigateTo(Routes.mainSignUpView);
  }

}