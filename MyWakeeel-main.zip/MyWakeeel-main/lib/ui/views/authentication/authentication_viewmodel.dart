
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class AuthenticationUpViewModel extends BaseViewModel{
  NavigationService _navigationService = locator<NavigationService>();
  String? currentPage;
   final list = {    
    'You are one step away from experiencing MyWakeel':'assets/images/expert.svg',
    'MyWakeel provide instant connections to lawyers around you':'assets/images/location.svg',
    'You can also view a lawyers profile before you start chatting with them': 'assets/images/profile.svg',

   };

updatePage(index){
  currentPage =index;
  notifyListeners();

}
 


  void navigateToSignIn() {
    _navigationService.navigateTo(Routes.signInView);
  }

  void navigateToSignUp() {
     _navigationService.navigateTo(Routes.mainSignUpView);
  }
}