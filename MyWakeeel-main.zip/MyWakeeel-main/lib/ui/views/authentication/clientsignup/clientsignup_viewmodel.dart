import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class ClientSignUpViewModel extends BaseViewModel{
  NavigationService _navigationService = locator<NavigationService>();
  AuthenticationService _authenticationService = locator<AuthenticationService>();
  String selectedText = 'Female';

  changeDropDown(value){
    selectedText = value;
    notifyListeners();
  }
  
  
  goBack()=> _navigationService.back();

  void navigateToSignIn(){
    _navigationService.navigateTo(Routes.signInView);

  }
  

  

  Future doSignUp(name, email, city,password, context, key) async{
   final result = await  _authenticationService.signUpWithEmail(
      password: password, userType: 'Client',court: 'N/A', context: context,
     name: name,  email: email, gender: selectedText, city:city, scaffoldKey:key,

    );
      if(result == 'true'){
      _navigationService.clearStackAndShow(Routes.signInView);
    }
  }
}