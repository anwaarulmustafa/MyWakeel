import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'clientsignup_viewmodel.dart';

class ClientSignUpView extends StatelessWidget {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final city = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ClientSignUpViewModel>.reactive(
        builder: (context, model, child) {
          return  Scaffold(
            key: scaffoldKey,
            body: kIsWeb? _buildWebView(model, context):
             _buildMobileView(model, context));
        },
        viewModelBuilder: () => ClientSignUpViewModel());
  }

  Widget _buildMobileView(ClientSignUpViewModel model, BuildContext context) {
    return SafeArea(
          child: SingleChildScrollView(
        child: Form(
          key: formKey,
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconButton(
              icon: Icon(Icons.arrow_back_ios),
              onPressed: model.goBack,
            ),
            smallHeight(context),
            iconHeader(context, 14),
            smallHeight(context),
            smallHeight(context),
            Text(
              'Register as a client',
              style: TextStyle(
                  fontSize: MySize.textSize(context, 6),
                  fontWeight: FontWeight.bold,
                  color: appColor),
            ),
            smallHeight(context),
            customTextField(hintText: 'Name', controller: name,
                    textInputAction: TextInputAction.next,),
            customTextField(hintText: 'Email', controller:  email,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,),
          
            customDropDown(model.selectedText, model.changeDropDown),
            customTextField(hintText: 'City',controller: city,
                    textInputAction: TextInputAction.next, ),
            customTextField(hintText: 'Password', controller: password,),
            SizedBox(
              height: 10,
            ),
            Align(
              alignment: Alignment.centerRight,
              child: InkWell(
                onTap: model.navigateToSignIn,
                child: Text(
                  ' Already have an account? Sign in->',
                  style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                      fontWeight: FontWeight.w400),
                ),
              ),
            ),
            smallHeight(context),
            customButton(context, text: 'Sign up', 
            onPressed:() async{
              if(formKey.currentState!.validate()){
               await model.doSignUp(name.text, email.text, city.text, password.text, context, scaffoldKey);
               }

            } ),
          ]),
        )),
      ));
  }

  Widget _buildWebView(ClientSignUpViewModel model, BuildContext context) {
    return  Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 3,
            child: Container(
              color: appColor,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Expanded(
                        child: Image.asset(
                      appIcon,
                      width: MySize.xMargin(context, 15),
                    ),),
                    Text(
                      'MyWakeel',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: MySize.textSize(context, 5.5),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                child: Form(
                    child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        mediumHeight(context),
                        Text(
                          'Register as a client',
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 6),
                              fontWeight: FontWeight.bold,
                              color: appColor),
                        ),
                        mediumHeight(context),
                         smallHeight(context),
            customTextField(hintText: 'Name', controller: name,
                    textInputAction: TextInputAction.next,),
            customTextField(hintText: 'Email', controller:  email,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,),
          
            customDropDown(model.selectedText, model.changeDropDown),
            customTextField(hintText: 'City',controller: city,
                    textInputAction: TextInputAction.next, ),
            customTextField(hintText: 'Password', controller: password,),
                        SizedBox(
                          height: 10,
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: InkWell(
                            onTap: model.navigateToSignIn,
                            child: Text(
                              ' Already have an account? Sign in->',
                              style: TextStyle(
                                  fontSize: MySize.textSize(context, 4),
                                  fontWeight: FontWeight.w400),
                            ),
                          ),
                        ),
                        smallHeight(context),
                        customButton(context,
                            text: 'Sign up', onPressed:()=> model.doSignUp(name.text, email.text, city.text, password.text, context, scaffoldKey)),
                      ]),
                )),
              ),
            ),
          ),
        ],
      );
  }
}
