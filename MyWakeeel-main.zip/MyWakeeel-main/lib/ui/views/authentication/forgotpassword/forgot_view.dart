import 'package:flutter/material.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/cupertino.dart';
import 'forgot_viewmodel.dart';
import 'package:flutter/foundation.dart';

class ForgotView extends StatelessWidget {
  final formKey = GlobalKey<FormState>();
  final webformKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final email = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ForgotViewModel>.reactive(
        builder: (context, model, child) {
          return Scaffold(
              key: scaffoldKey,
              body: kIsWeb
                  ? _webView(model, context)
                  : _mobileView(model, context));
        },
        viewModelBuilder: () => ForgotViewModel());
  }

  Widget _mobileView(ForgotViewModel model, context) {
    return Form(
        key: formKey,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconButton(
              icon: Icon(Icons.arrow_back_ios),
              onPressed: () => model.goBack(),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              'Forgot Password',
              style: TextStyle(
                  fontSize: MySize.textSize(context, 10),
                  fontWeight: FontWeight.bold,
                  color: appColor),
            ),
            SizedBox(
              height: MySize.yMargin(context, 15),
            ),
            Text(
              'Please, enter your email address. You will recieve a link to create a new password.',
              style: TextStyle(
                  fontSize: MySize.textSize(context, 4.5),
                  color: Colors.grey[800]),
            ),
            SizedBox(
              height: 10,
            ),
            customTextField(
              hintText: 'Email',
              controller: email,
            ),
            SizedBox(
              height: 30,
            ),
            customButton(context, text: 'Recover', onPressed: () {
              if (formKey.currentState!.validate()) {
                model.doRecover(email.text, context, scaffoldKey);
              }
            }),
            Spacer(),
          ]),
        ));
  }

  Widget _webView(ForgotViewModel model, context) {
    return Form(
        key: webformKey,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child:
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,

               children: [
            Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                icon: Icon(Icons.arrow_back_ios),
                onPressed: () => model.goBack(),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              'Forgot Password',
              style: TextStyle(
                  fontSize: MySize.textSize(context, 6),
                  fontWeight: FontWeight.bold,
                  color: appColor),
            ),
            SizedBox(
              height: MySize.yMargin(context, 8),
            ),
            Text(
              'Please, enter your email address. You will recieve a link to create a new password.',
              style: TextStyle(
                  fontSize: MySize.textSize(context, 2.5),
                  color: Colors.grey[800]),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MySize.xMargin(context, 4.5)),
              child: customTextField(hintText: 'Email', controller: email)),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: MySize.xMargin(context, 4.5)),
              child: customButton(context, text: 'Recover', onPressed: () {
                if (webformKey.currentState!.validate()) {
                  model.doRecover(email.text, context, scaffoldKey);
                }
              }),
            ),
            Spacer(),
          ]),
        ));
  }
}
