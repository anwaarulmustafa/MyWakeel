import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class ForgotViewModel extends BaseViewModel{
  
  NavigationService _navigationService = locator<NavigationService>();
  AuthenticationService _authenticationService = locator<AuthenticationService>();
  goBack()=> _navigationService.back();
   Future doRecover(String email, context, scaffoldKey) async {
    await  _authenticationService
    .sendChangePasswordEmail(email: email, context:context, scaffoldKey: scaffoldKey);
    

  
  }
  
}