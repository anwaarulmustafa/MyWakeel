import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class MainSignUpViewModel extends BaseViewModel{
   NavigationService _navigationService = locator<NavigationService>();
 

  
  navigateToLawyerSignUp(){
    _navigationService.navigateTo(Routes.lawyerSignUpView);

  }
  navigateToClientSignUp(){
    _navigationService.navigateTo(Routes.clientSignUpView);

  }
  
  goBack()=> _navigationService.back();


}