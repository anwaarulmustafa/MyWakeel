import 'package:flutter/material.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/cupertino.dart';
import 'mainsignup_viewmodel.dart';

class MainSignUpView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<MainSignUpViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
        body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               IconButton(
                      icon: Icon(Icons.arrow_back_ios),
                      onPressed: model.goBack,


                    ),

              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      
                      Container(
                        height: 100,
                        width: 100,
                        child: Image(image: AssetImage('assets/images/icon.png'))),
                         SizedBox(
                  height:5
              ),
                      Text('MyWakeel',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                      ),
                         SizedBox(
                  height:20
              ),
                      Text('You are one step away from experiencing MyWakeel',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontStyle: FontStyle.italic
                      ),
                      ),
                    ],
                  ),
                ),
              ),

              Container(
                width: double.infinity,
                height: 60,
                child: OutlinedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(appColor),
                    shape:  MaterialStateProperty.all(RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)))
                  ),
                  
                  onPressed:(){
                    model.navigateToClientSignUp();

                  } ,
                  child: Center(child: Text('I need a lawyer', style: TextStyle(color: Colors.white),)),

                ),
              ),

              SizedBox(
                height:10
              ),
              Container(
                width: double.infinity,
                height: 60,
                child: OutlinedButton(
                  style: ButtonStyle(
                    shape:  MaterialStateProperty.all(RoundedRectangleBorder(
                      side: BorderSide(
                        width: 2,
                        color: Colors.black,
                        style: BorderStyle.solid
                      ),
                      borderRadius: BorderRadius.circular(10)))
                  ),
                  
                  onPressed:()=> model.navigateToLawyerSignUp(),
                  child: Center(child: Text('I am a lawyer',
                   style: TextStyle(color: Colors.black),)),

                ),
              ),
            ]
          ),
        ),
        ),


      );
      }, 
      viewModelBuilder: ()=>MainSignUpViewModel());
    
  }
}

