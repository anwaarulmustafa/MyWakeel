import 'package:flutter/material.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/models/message_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/views/messages/personal_message/personal_message_view.dart';
import 'package:stacked/stacked.dart';

class MessageViewModel extends BaseViewModel{
  
  FirebaseService  _firebaseService = locator<FirebaseService>();
   late MessageDetails  messageDetails;
   List<MessageDetails> messages =[];

   navigateToSingleMessage(index, context){
      Navigator.push(context, MaterialPageRoute(builder: (context) {
          return PersonalMessageView(
            messageDetails: messages[index],
          );
        }));

   }
   
   getMessage() async {
     setBusy(true);
    notifyListeners();
    messages = await _firebaseService.getMessages();
     setBusy(false);
    notifyListeners();

   }
}