import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mywakeel/models/message_details.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_text.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'message_viewmodel.dart';

class MessageView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<MessageViewModel>.reactive(
        builder: (context, model, child) {
          return Scaffold(
            body: Column(
              children: <Widget>[
                SafeArea(
                  child: Padding(
                    padding: EdgeInsets.only(left: 16, right: 16, top: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          "Messages",
                          style: TextStyle(
                            fontSize: MySize.textSize(context, 9),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                showBusy(model),
                Visibility(
                  child: Visibility(
                      visible: model.messages.length != 0,
                      replacement: Expanded(
                    child:  Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       
                        Container(
                          height: MySize.yMargin(context, 50),
                          
                          width: MySize.xMargin(context, 60),
                          child: SvgPicture.asset('assets/images/empty.svg',
                          //  fit: BoxFit.cover,
                           ),),
                        smallHeight(context),
                         Text('You have no messages yet.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 5),
                  ),),
                      ],
                    ),
                  ),
                      child: ListView.builder(
                        itemCount: model.messages.length,
                        shrinkWrap: true,
                        padding: EdgeInsets.only(top: 16),
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          final chatMessage = model.messages[index];
                          return GestureDetector(
                            onTap: () {
                              model.navigateToSingleMessage(index, context);
                            },
                            child: ConversationList(chatMessage),
                          );
                        },
                      )),
                ),
              ],
            ),
          );
        },
        onModelReady: (model) {
          model.getMessage();
        },
        viewModelBuilder: () => MessageViewModel());
  }
}

class ConversationList extends StatefulWidget {
  final MessageDetails message;
  ConversationList(this.message);
  @override
  _ConversationListState createState() => _ConversationListState();
}

class _ConversationListState extends State<ConversationList> {
  bool isRead = false;
  @override
  Widget build(BuildContext context) {
     isRead = widget.message.isRead!;
    print(widget.message.isRead);
    return Container(
      padding: EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 10),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Row(
              children: <Widget>[
                CircleAvatar(
                  backgroundColor: appColor,
                  backgroundImage: AssetImage('assets/images/icon.png'),
                  // widget.imageUrl),
                  maxRadius: 30,
                ),
                SizedBox(
                  width: 16,
                ),
                Expanded(
                  child: Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          widget.message.senderName!,
                          style:
                              TextStyle(fontSize: MySize.textSize(context, 5)),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        Text(
                          widget.message.recentmessage!,
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 4),
                              color: Colors.grey.shade600,
                              fontWeight: isRead
                              ?
                                    FontWeight.bold
                                  : FontWeight.normal),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text(
            formatDate(widget.message.recentMessageTime!),
            style: TextStyle(
                fontSize: MySize.textSize(context, 4),
                fontWeight:isRead?  FontWeight.bold : FontWeight.normal),
          ),
        ],
      ),
    );
  }
}
