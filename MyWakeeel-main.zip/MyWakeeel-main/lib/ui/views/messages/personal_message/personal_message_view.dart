import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:mywakeel/models/message_details.dart';
import 'package:mywakeel/models/messages_model.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';
import 'package:grouped_list/grouped_list.dart';
import 'personal_message_viewmodel.dart';

class PersonalMessageView extends StatelessWidget {
  final MessageDetails? messageDetails;
  final UserDetails? details;
  PersonalMessageView({this.messageDetails, this.details});
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PersonalMessageViewModel>.reactive(
        builder: (context, model, child) {
          return Scaffold(
            appBar: AppBar(
              elevation: 0,
              automaticallyImplyLeading: false,
              backgroundColor: Colors.white,
              flexibleSpace: SafeArea(
                child: Container(
                  padding: EdgeInsets.only(right: 16),
                  child: Row(
                    children: <Widget>[
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      model.imageUrl != null? 
                      CircleAvatar(
                        backgroundColor: appColor,
                        backgroundImage: NetworkImage(model.imageUrl!),
                       maxRadius: 20,
                      ):CircleAvatar(
                        backgroundColor: appColor,
                        backgroundImage:AssetImage(appIcon),
                       maxRadius: 20,
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      Expanded(
                        child: Text(
                          '${model.name}',
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 5),
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      
                      Visibility(
                        visible: AppRepo.isLawyer!,
                        child: PopupMenuButton<int>(
                        icon: Icon(Icons.more_vert_rounded, color: appColor),
                        itemBuilder: (context) => [
                          PopupMenuItem(value: 0, child: Text('Refer')),
                        ],
                        onSelected: (int index) {
                           showDialog(
                                  context: context,
                                  builder: (context) {
                                    return ReferDialog(model);
                                  });
                        },
                      ))
                      
                    ],
                  ),
                ),
              ),
            ),
            body: Stack(
              children: <Widget>[
                Visibility(
                  visible: model.message.length !=0,
                  replacement: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          height: MySize.yMargin(context, 60),
                          width: MySize.xMargin(context, 80),
                          child: SvgPicture.asset(
                            'assets/images/message.svg',  
                          height: MySize.yMargin(context, 60),
                          width: MySize.xMargin(context, 80),
                          fit: BoxFit.scaleDown,
                            )
                          ),
                        Text('No messages yet',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: MySize.textSize(context, 4)),
                        ),

                      ]
                    ),
                  ),
                  child: Padding(
                  padding: const EdgeInsets.only(bottom: 70),
                  child:
                   Expanded(
                     child: GroupedListView<Message, DateTime>(
                  elements: model.message,
                  order: GroupedListOrder.ASC,
                  floatingHeader: true,

                  groupBy: (Message element)  =>DateTime( DateTime.parse(element.time!).year, DateTime.parse(element.time!).month,DateTime.parse(element.time!).day, ),
                  groupSeparatorBuilder: (DateTime element)=> Center(child: Text(DateFormat('MMMM d').format(element))),
                  itemComparator: (Message element1,  Message element2)=> DateTime.parse(element1.time!)
                  .compareTo(DateTime.parse(element2.time!)),
                  itemBuilder: (_, Message element)=> Container(
                          padding: EdgeInsets.only(
                              left: 14, right: 14, top: 10, bottom: 10),
                          child: Align(
                            alignment: (element.senderId != model.currentUserId?
                                 Alignment.topLeft
                                : Alignment.topRight),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                color: (element.senderId == model.currentUserId?
                                     Colors.grey.shade200
                                    : appColor),
                              ),
                              padding: EdgeInsets.all(8),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Text(
                                      element.message!,
                                      style: TextStyle(
                                          fontSize: MySize.textSize(context, 4)),
                                    ),
                                  ),
                                  smallWidth(context),
                                  Align(
                            alignment: Alignment.bottomCenter,
                                    child: Text(  DateFormat.jm().format(DateTime.parse(element.time!)),
                                      textAlign: TextAlign.end,
                                      style: TextStyle(
                                        color: Colors.black.withOpacity(0.6),
                                          fontSize: MySize.textSize(context, 2.8)),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                  ),
                   ),
                ),),
                
                Align(
                  alignment: Alignment.bottomLeft,
                  child: Container(
                    padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
                    height: 60,
                    width: double.infinity,
                    color: Colors.white,
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 15,
                        ),
                        Expanded(
                          child: TextField(
                            controller: controller,
                            decoration: InputDecoration(
                                hintText: "Write message...",
                                hintStyle: TextStyle(color: Colors.black54),
                                border: InputBorder.none),
                          ),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        FloatingActionButton(
                          onPressed: () {
                            model.sendMessage(controller.text);
                            controller.text = '';
                          },
                          child: Icon(
                            Icons.send,
                            color: Colors.white,
                            size: MySize.xMargin(context, 6),
                          ),
                          backgroundColor: appColor,
                          elevation: 0,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
        onModelReady: (model) {
          if(messageDetails!=null){
            model.onMesReady(messageDetails!);

          }else{
            
          model.onDetReady(details!);
          }
          
        },
        viewModelBuilder: () => PersonalMessageViewModel());
  }

}

class ReferDialog extends StatelessWidget {
  final PersonalMessageViewModel? model;
  ReferDialog(this.model);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: EdgeInsets.all(12),
      content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
        return Container(
          height: MySize.yMargin(context, 50),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Refer to:',
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 6),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                 
                smallHeight(context),
                Visibility(
                  visible: model!.selectedName !=null,
                  child:   ListTile(
                  leading:  Text('${model!.selectedName}',
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 5),
                  ),
                ),
                trailing: IconButton(
                  icon: Icon(Icons.cancel),
                  onPressed: (){
                    setState((){
                      
                    model!.clear();

                    });
                  }
                  ),
                ),
                ),
                 Column(
                    children: [
                      TextField(
                      decoration: InputDecoration(
                          hintText: 'Lawyer\'s name',
                          border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey[400]!))
                              ),
                      onSubmitted: (String value) async {
                        await  model!.searchUser(value);
                        setState((){});

                      }
                ),
                smallHeight(context),
                Visibility(
                  visible:  model!.searchedUsers.length !=0,
                  child:  Container(
                        height: MySize.yMargin(context, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Search Results'),
                      minHeight(context),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: model!.searchedUsers.length,
                        itemBuilder: (context, index){
                        return InkWell(
                          onTap: (){
                            setState((){
                              
                            model!.getSelectedUser(index);

                            });
                          },
                          child: Card(
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text('${model!.searchedUsers[index].name}'),
                              )),
                          ));
                      }),
                    ],
                  )),
                )
                    ],
                  ),
              
               
                smallHeight(context),
                      Text('Referring:',
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 6),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                      smallHeight(context),
                      Text('${model!.name}',
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 5),
                  ),
                ),
                 
                smallHeight(context),
                Container(
                      height: 60,
                      width: double.infinity,
                      color: appColor,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: appColor,

                    ),
                    
                    onPressed: () {
                      model!.referUser();
                    },
                     child: Text('Refer Client')),
                )
              ],
            ),
          ),
        );
      }),
    );
  }
}
