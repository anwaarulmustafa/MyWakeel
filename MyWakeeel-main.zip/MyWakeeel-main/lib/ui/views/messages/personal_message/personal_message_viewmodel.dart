import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/models/message_details.dart';
import 'package:mywakeel/models/messages_model.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';

import 'package:stacked_services/stacked_services.dart';


class PersonalMessageViewModel extends BaseViewModel{
  FirebaseService _firebaseService = locator<FirebaseService>();
     MessageDetails? messageDetails;
    UserDetails?  details;
    late UserDetails selected;
    List<UserDetails> searchedUsers = [];
   String? userId;
   List<Message> message =[];
   String currentUserId= AppRepo.firebaseCurrentUser!.uid;
   String? name, imageUrl, selectedName;
   NavigationService _navigationService = locator<NavigationService>();
  
 

  goBack() => _navigationService.back();

   onDetReady(UserDetails user){
        details = user;
        
        setDetails(details!.name, details!.imageUrl, details!.uid);
       userId =user.uid;

     notifyListeners();
   }

    onMesReady(MessageDetails mes,){
     
       messageDetails =mes;
        setDetails(mes.senderName,mes.senderImageUrl,mes.recieverId);
       getSingleMessage();

     notifyListeners();
   }

   setDetails(userName, url, id){
     name = userName;
       userId =id;
       imageUrl =url;

   }

   getSingleMessage() async {
    message = await  _firebaseService.getSingleMessages(messageDetails!.chatId);
     notifyListeners();

   }
  //  sortMessages(){
  //   final mes= message.reversed.toList();
  //  mes.sort((a,b) =>readFromString(b.time).compareTo(readFromString(a.time)));
  //   Message prev;
  //   bool showHeader = false;
  //    mes.forEach((message) {
  //     if(prev !=null && readFromString(message.time) !=readFromString(prev.time)){
  //       showHeader = false;
  //       notifyListeners();
  //     }
  //    });
  //  }

   sendMessage(String text) async {
     if(text.isNotEmpty){
       message.add(Message(
         senderId: AppRepo.firebaseCurrentUser!.uid, 
         message:  text, 
         time: DateTime.now().toString()));
         
     notifyListeners();
     if(messageDetails !=null){
       
     _firebaseService.sendMessage(details!.uid!, text, messageDetails!);

     }else{
       _firebaseService.sendMessage(details!.uid!, text, null);

     }
         
     }


    



   }

     searchUser(String searchTerm) async{
       searchedUsers =[];
      final  allUsers = await _firebaseService.searchLawyers();
        allUsers.forEach((element) {
          if(element.name ==searchTerm ){
            searchedUsers.add(element);

          }
         });
     notifyListeners();
   }
   
   getSelectedUser(index){
     selected = searchedUsers[index];
     selectedName =selected.name;
     notifyListeners();
     
   }
   clear(){
     selectedName =null;
     notifyListeners();

   }

   referUser() async {
     if(selected.name !=null){
       
     await _firebaseService.referUser(details!.name, details!.uid,
      selected.name, selected.uid).whenComplete(() => goBack());

     }
     
   }


}