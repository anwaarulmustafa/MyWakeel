import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/models/notifications_details.dart';
import 'package:mywakeel/models/refer_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';

class NotificationsViewModel extends BaseViewModel{
  
  FirebaseService _firebaseService = locator<FirebaseService>();
   int currentTab = 0;
   List<NotificationsDetails> notifications =[];
   List<ReferDetails> reffers =[];

   onReady(){
     notifications = AppRepo.currentUserDetails!.notifications!;
     notifyListeners();
     
     
   }
   update(){
     notifications.where((element) => element.isRead =false)
     .forEach((notif) async { 
       

     await _firebaseService.updateNotification(notif);
     });
   }
   getReffered(){
     notifications.forEach((element) {
       if(element.notificationType =='Refer'){

       }
       
     });
     

   }
}