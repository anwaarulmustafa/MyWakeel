import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_text.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'notifications_viewmodel.dart';

class NotificationsView  extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<NotificationsViewModel>.reactive(
      builder: (context, model, child){
        return  DefaultTabController(
          length: 2,
          child: Scaffold(
            body:  Column(
              children: [
                SafeArea(
                    child: Padding(
                      padding: EdgeInsets.only(left: 16,right: 16,top: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text("Notifications",style: TextStyle(fontSize: 32,fontWeight: FontWeight.bold),),
                         ],
                      ),
                    ),
                  ),
                 
                 
                  Visibility(
                    visible: model.notifications.length !=0,
                    child:  _lawyerReferScreen(model),
                    replacement: Expanded(
                    child:  Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       
                        Container(
                          height: MySize.yMargin(context, 50),
                          
                          width: MySize.xMargin(context, 60),
                          child: SvgPicture.asset('assets/images/empty.svg',
                           ),),
                        smallHeight(context),
                         Text('You have no notifications yet.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: MySize.textSize(context, 5),
                  ),),
                      ],
                    ),
                  ),
                  ),
                             ],
            ),
          ),
        );

      }, 
      onModelReady: (model){
        model.onReady();

      },
      viewModelBuilder: ()=>NotificationsViewModel());
  }
  Widget _referItem (context, text, date){
    return Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(Icons.assignment_ind),
                       smallWidth(context),
                  Text(text,
                  style: TextStyle(fontSize: MySize.textSize(context, 4),),)
                    ],
                  ),
                   Text(formatDate(date),
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: MySize.textSize(context, 3.5),),)
                 
                ]
          ),
              ),
            );
  }
  
  Widget _lawyerReferScreen(NotificationsViewModel model){

    return Expanded(
      child: ListView.builder(
        itemCount: model.notifications.length,
        itemBuilder:(context, index){
          final notif = model.notifications.reversed.toList()[index];
          switch (notif.notificationType) {
            case 'Refer':
            return _referItem (context, 'You were reffered.', notif.date);
           case 'Referred':
            return _referItem (context, 'You have a new reffered Case.', notif.date);
          case 'Refer Accepted':
             return _referItem (context, 'A case you reffered got accepted.', notif.date); 
              case 'Refer Rejected ':
             return _referItem (context, 'A case you reffered got rejected.', notif.date);
             case 'Hire Accepted':
             return  _referItem (context, 'An offer you sent got rejected', notif.date);

             case 'Hire Rejected':
             return  _referItem (context, 'An offer you sent got rejected', notif.date);

             case 'Hired':
             return   _referItem (context, 'You have a new job.', notif.date);

            case 'Follow':
             return   _referItem (context, 'You have a new follower.', notif.date);
          }
          return Container();

         
        }
      ),
    );
  }
 
}