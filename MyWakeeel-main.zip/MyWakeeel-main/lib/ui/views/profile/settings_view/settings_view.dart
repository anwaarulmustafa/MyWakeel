import 'package:flutter/material.dart';

import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'settings_viewmodel.dart';

class SettingsView extends StatelessWidget {
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SettingsViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
          appBar: AppBar(
            title: Text('Settings'),),
          body: Column(
            children: [
              smallHeight(context),
              Card(
                child: ListTile(
                  onTap: model.navigateToEditProfile,
                  leading: Text('Edit Profile'),
                  trailing: Icon(Icons.arrow_right),
                  ),
              ),
               Card(
                child: ListTile(
                  onTap: (){},
                  leading: Text('Privacy Policy'),
                  trailing: Icon(Icons.arrow_right),
                  ),
              ),
               Card(
                child: ListTile(
                  onTap: (){},
                  leading: Text('Share'),
                  trailing: Icon(Icons.arrow_right),
                  ),
              ),
               Card(
                child: ListTile(
                  onTap: (){
                    showDialog(context: context, builder: (context){
                      return Container(
                        height: MySize.yMargin(context, 30),
                        child: AlertDialog(
                          title: Text('Delete Account?'),
                          content: Container(
                        height: MySize.yMargin(context, 30),
                            child: Column(
                              children: [
                                Text('Are you sure you want to delete your account? '),
                                TextField(
                                  maxLines: 5,
                                  controller: controller,
                                  decoration: InputDecoration(
                                    hintText: 'Please provide reason for deleting',
                                  ),
                                  
                                   ),

                              ],
                            ),
                          ),
                          actions: [
                            ElevatedButton(onPressed: (){
                              if(controller.text.length !=0){
                                   model.delete();

                              }else{
                                 ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Please tell us a reason')));

                              }
                            },
                             child: Text('Yes')),
                              ElevatedButton(onPressed: (){
                              model.goBack();
                            },
                             child: Text('No'))
                          ],
                          
                          

                        ),
                      );

                    });
                    },
                  leading: Text('Delete Account'),
                  trailing: Icon(Icons.arrow_right),
                  ),
              ),
               Card(
                child: ListTile(
                  onTap: model.logout,
                  leading: Text('Logout'),
                  trailing: Icon(Icons.arrow_right),
                  ),
              ),
             
              
            ],
          ),
        );
      }, 
      viewModelBuilder: ()=>SettingsViewModel());
  }
}