import 'package:flutter/foundation.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class SettingsViewModel extends BaseViewModel{
   AuthenticationService _authenticationService =
      locator<AuthenticationService>();
  NavigationService _navigationService = locator<NavigationService>();

  goBack() => _navigationService.back();

  logout() {
    _authenticationService.signOut()
    .whenComplete(() => _navigationService.clearStackAndShow(Routes.authenticationUpView)
    );
  }

  delete() {
     
    _authenticationService.deleteUser()
    .whenComplete(() => _navigationService.clearStackAndShow(
      kIsWeb?Routes.authenticationUpView:Routes.signInView));
  }


  navigateToEditProfile() {
    _navigationService.navigateTo(Routes.editProfileView);
  }
  navigateToSettings() {
    _navigationService.navigateTo(Routes.settingsView);
  }

}