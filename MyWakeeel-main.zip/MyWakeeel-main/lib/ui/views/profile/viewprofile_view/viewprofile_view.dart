import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/shared/feed_card.dart';
import 'package:stacked/stacked.dart';
import 'viewfollows.dart';
import 'viewprofile_viewmodel.dart';

class ViewProfileView  extends StatelessWidget {
  final UserDetails? details;
  final String? id;
  ViewProfileView({this.details,this.id});
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ViewProfileViewModel>.reactive(
      builder: (context, model, child){
          
               return Visibility(
                 visible: !model.isBusy,
                 replacement: Scaffold(
                   body:  Center(
                     child: CircularProgressIndicator(
                     valueColor: AlwaysStoppedAnimation<Color>(appColor),
                 ),
                   ),
                 ),
                 child:
                //  Visibility(
                //    replacement: _clientProfileScreen(model, context),
                //    visible: AppRepo.isLawyer!,
                //    child:
                    _lawyerProfileScreen(model, context)
                    // ),
               );

      },
      onModelReady: (model){
        if(id !=null){ 
          model.onReadyget(id!);

        }else{
          model.onReady(details!);

        }
      },
      viewModelBuilder: ()=>ViewProfileViewModel());
  }
  Widget header( ViewProfileViewModel model, context){
    UserDetails details = model.details;
    return Column(
      children: [
          SafeArea(
                child: Padding(
                  padding: EdgeInsets.only(left: 16, right: 16, top: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        "Profile",
                        style: TextStyle(
                            fontSize: MySize.textSize(context, 9),
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
              smallHeight(context),
              Card(child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: MySize.xMargin(context, 30),
                        width: MySize.xMargin(context, 30),
                        child: details.imageUrl !=null? CircleAvatar(
                          backgroundImage: NetworkImage(details.imageUrl!),
                          radius: 50.0,
                        ):CircleAvatar(
                          backgroundImage: AssetImage(appIcon),
                          radius: 50.0,
                        )
                      ),
                      Text("${details.name}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 26.0,
                              fontWeight: FontWeight.bold)),
                      Text(
                        "${details.email}",
                        style: TextStyle(
                            fontSize: MySize.textSize(context, 4),
                            fontWeight: FontWeight.bold),
                      ),
                      Text("${details.gender}",
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 4),)),
                                Text("${details.city}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15.0,
                              fontWeight: FontWeight.normal)),
                      Visibility(
                        visible: details.userType =='Lawyer',
                        child: Text(
                          "${AppRepo.currentUserDetails!.court}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ),   
                      smallHeight(context) ,    
                      Visibility(
                        visible: !AppRepo.isLawyer!,
                        replacement:  Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: (){
                                Navigator.of(context)
                                .push(CupertinoPageRoute(builder: (context)=> ViewFollows(model.details, true)));
                              },
                              child: Text('${NumberFormat.compact().format(double.parse('${model.noOFFollowers}'))}\n Followers',
                              textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 4.5),)),
                            ),
                            Container(
                            width: MySize.xMargin(context, 30),
                            height: 50,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                primary: appColor
                              ),
                              onPressed: (){
                                model.followUser();
                              },
                              child: Text(model.isFollowing? 'Unfollow': 'Follow',
                              style: TextStyle(
                                  fontSize: MySize.textSize(context, 4),)),

                            )
                            ), 
                            InkWell(
                              onTap: (){
                                 Navigator.of(context)
                                .push(CupertinoPageRoute(builder: (context)=> ViewFollows(model.details, false)));
                              },
                              child: Text('${NumberFormat.compact().format(double.parse('${model.noOFFollowing}'))}\n Following',
                              textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 4.5),)),
                            ),
                          ],
                        ),
                        child:  Center(
                          child: Container(
                          width: MySize.xMargin(context, 60),
                          child: Row(
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: appColor
                                  ),
                                  onPressed: (){
                                      model.showHireDialog(context, HireItem(model));
                                  },
                                  child: Text('Hire',
                                  style: TextStyle(
                                      fontSize: MySize.textSize(context, 4),)),

                                ),
                              ),
                            smallWidth(context),
                               Expanded(
                                 child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: appColor
                                  ),
                                  onPressed: (){
                                    model.sendMessage(context);
                                  },
                                  child: Text('Message',
                                  style: TextStyle(
                                      fontSize: MySize.textSize(context, 4),)),

                              ),
                               ),
                            ],
                          )
                          ),
                        )),
                    ],
                  ),
                ),
              ),
              ),
      ],
    );
  }

  Widget _lawyerProfileScreen( ViewProfileViewModel model, context) {
    return Scaffold(
      body: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               header(model , context),
                      
               
            

              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: 
                            Text(
                            "Experience",
                            style: TextStyle(
                                fontSize: MySize.textSize(context, 6),
                                fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                     
                      Visibility(
                        visible: model.experience.length ==0,
                        replacement:  ListView.builder(
                          padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: model.experience.length,
                            itemBuilder: (context, index) {
                              final exp = model.experience[index];
                              return  Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Divider(color: Colors.grey[400]),
                                            smallHeight(context),
                                            Text(
                                              "${exp.jobTitle} | ${exp.clients} ",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 5),
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.date}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w300),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.summary}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w400),
                                            ),
                                          ],
                                        );
                             
                            }) ,
                        child: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text('No Completed Job',
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 5),),),
                          ),
                        ),)
                      ),
                    ],
                  ),
                ),
              ),
               Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                          "Completed Jobs",
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 6),
                              fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                       Visibility(
                        visible: model.completed.length !=0,
                        replacement: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text('No Completed Job',
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 5),),),
                          ),
                        ),),
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: model.completed.length,
                            itemBuilder: (context, index) {
                              final exp = model.completed[index];
                              return  Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Divider(color: Colors.grey[400]),
                                            smallHeight(context),
                                            Text(
                                              "${exp.hiredBy} ",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 5),
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.dateHired } |${exp.dateUpdated }",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w300),
                                            ),
                                            smallHeight(context),
                                            // Text(
                                            //   "${exp.summary}",
                                            //   style: TextStyle(
                                            //       fontSize: MySize.textSize(context, 4),
                                            //       fontWeight: FontWeight.w400),
                                            // ),
                                          ],
                                        );
                             
                            }),
                             ),
                   
                    ],
                  ),
                ),
              ),

                 Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                          "Certifications",
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 6),
                              fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                      
                     
                      Visibility(
                        visible: model.certificates.length ==0,
                        replacement:  ListView.builder(
                          padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: model.certificates.length,
                            itemBuilder: (context, index) {
                              final exp = model.certificates[index];
                              return  Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "${exp.title}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 5),
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.date}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w300),
                                            ),
                                          ],
                                        );
                             
                            }) ,
                        child: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(child: Text('Add a certificate'))),
                      ),
                    ],
                  ),
                ),
              ),
              Visibility(
                visible: AppRepo.isLawyer!,
                child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                          "Lawyer's Feeds",
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 6),
                              fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                      Visibility(
            visible: model.feeds.length!=0,
            replacement: Container(),
            child:
             ListView.builder(
               shrinkWrap: true,
               physics: NeverScrollableScrollPhysics(),
                  itemCount: model.feeds.length,
                  itemBuilder: (context, index) {
                    final feed = model.feeds[index];
                    return 
                     FeedCard(feed: feed,);
                  },
                ),
          ),
                    ],
                  ),
                ),
              ),),

               
              
            ],
          )),
    );
  }

   

}

class HireItem extends StatefulWidget{
  final ViewProfileViewModel model;
  HireItem(this.model);

  @override
  _HireItemState createState() => _HireItemState();
}

class _HireItemState extends State<HireItem> {
    final TextEditingController jobTitle = new TextEditingController();

    final TextEditingController summary = new TextEditingController();
    final _formKey = GlobalKey<FormState>();
    

    @override
    Widget build(BuildContext context) {
      return   Scaffold(
        appBar: AppBar(
           title:  Text('Hire Lawyer'),
        ), 
        body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Card(
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child:
                                               Text(
                                                'You are about to hire ${widget.model.details.name}, please add a title and a description for your case.',
                                                        style: TextStyle(
                                                          color: Colors.grey[800],
                                                            fontSize: MySize.textSize(context, 4.5),)
                                                ),
                                            ),
                                          ),
                                          smallHeight(context),
                                        TextFormField(
                                          controller: jobTitle,
                                          validator:(value)=> validator(value!),
                                          decoration: InputDecoration(
                                             hintText: 'Job Title',
                                             enabledBorder: OutlineInputBorder(
                                               borderSide: BorderSide(color: appColor)),
                                            focusedBorder: OutlineInputBorder(
                                               borderSide: BorderSide(color: appColor)),

                                          ),
                                          ),
                                          smallHeight(context),
                                          TextFormField(
                                          controller: summary,
                                          maxLines: 8,
                                          validator:(value)=> validator(value!),
                                          
                                          decoration: InputDecoration(
                                             hintText: 'Description',
                                             enabledBorder: OutlineInputBorder(
                                               borderSide: BorderSide(color: appColor)),
                                            focusedBorder: OutlineInputBorder(
                                               borderSide: BorderSide(color: appColor)),

                                          ),
                                          ),
                                          smallHeight(context),

                                          Container(
                                            height: 50,
                                            width: double.infinity,
                                            child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                primary: appColor,
                                              ),
                                              
                                              onPressed: (){
                                                if(_formKey.currentState!.validate()){
                                                  widget.model.hireUser(context, summary.text, jobTitle.text);
                                                 }
                                              },
                                             child: Center(child: Text('Send offer'))),
                                          )


                                       
                                      ],
                                    ),
            ),
          ),
        ),
      );
    }
}
