import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/models/follow_details.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'viewprofile_view.dart';
import 'viewprofile_viewmodel.dart';
class ViewFollows extends StatelessWidget {
  final UserDetails details;
  final bool isFollowers;
  ViewFollows(this.details, this.isFollowers);
  @override
  Widget build(BuildContext context) {
    List<FollowDetails> followDetails =isFollowers? details.followers!:details.follows!;
    return ViewModelBuilder<ViewProfileViewModel>.reactive(
      builder: (context, model, child){
           return Scaffold(
             appBar: AppBar(title: Text(isFollowers?'Followers':'Following'),),
             body: ListView.builder(
               itemCount: followDetails.length,
                   itemBuilder: (BuildContext context, int index){
                     final list = followDetails[index];
                     return InkWell(
                onTap: (){
                 Navigator.of(context).push(MaterialPageRoute(
                   builder: (context)=>ViewProfileView(id:list.uid)));

                },
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                           Container(
                                height: MySize.xMargin(context, 15),
                                width: MySize.xMargin(context, 15),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50),
                                  image:  list.imageUrl !=null?
                                   DecorationImage(
                                     fit: BoxFit.cover,
                                    image: 
                                    NetworkImage(list.imageUrl!),
                                  ): 
                                   DecorationImage(
                                     fit: BoxFit.cover,
                                    image: AssetImage("assets/images/icon.png",),
                                  ),
                                    ),
                              ),
                         
                          smallWidth(context),
                          Text(
                            '${list.name}',
                            style: TextStyle(
                              fontSize: MySize.textSize(context, 7),
                            ),
                          )
                        ],
                      ),
                    ),
                  Divider(),
                  ],
                ),
              );
                   }
                   
                   )
           );

      },
      onModelReady: (model){
        model.onReady(details);
      },
      viewModelBuilder: ()=>ViewProfileViewModel());
}
}