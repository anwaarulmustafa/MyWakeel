import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/models/certification_details.dart';
import 'package:mywakeel/models/experience_details.dart';
import 'package:mywakeel/models/hire_details.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/views/messages/personal_message/personal_message_view.dart';
import 'package:stacked/stacked.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:mywakeel/models/feed_details.dart';

class ViewProfileViewModel extends BaseViewModel{
  
  FirebaseService _firebaseService = locator<FirebaseService>();

 UserDetails details = UserDetails();
    List<ExperienceDetails> experience=[];
  List<CertificationsDetails> certificates=[];
  List<HireDetails> completed =[];
  List<FeedDetails> feeds =[];
   NavigationService _navigationService = locator<NavigationService>();
   bool isFollowing = false;
   int noOFFollowers =0, noOFFollowing =0;
  
 

  goBack() => _navigationService.back();
  onReady(UserDetails user) async {
    setBusy(true);
    notifyListeners();
    
    details = user;
    getUserDetails(user);
    
    setBusy(false);
    notifyListeners();
    

  }
  onReadyget(String id) async {
    setBusy(true);
    notifyListeners();

    final user = await _firebaseService.getFollowUser(id);
    details = user;
   
    getUserDetails(user);
    
    setBusy(false);
    notifyListeners();
    

  }
  getUserDetails(UserDetails user) async{
     if(user.userType == 'Lawyer'){
      
    experience = user.experience!;
    certificates = user.cetifications!;
    log('j ${user.followers!.length}');
     noOFFollowers = user.followers!.length;
    noOFFollowing = user.follows!.length;
    final t = AppRepo.currentUserDetails!.follows!.where((e) => e.uid ==user.uid).isNotEmpty;

    isFollowing = t;
    await  getHires();
    await getUserFeeds();
     }

  }

   getHires() async {
    final hire = await _firebaseService.getHires();
    hire.forEach((element) { 
      if(element.hiredUserId == details.uid){
        if(element.isReacted!){
          if(element.isAccepted! &&element.inCompleted!){
            completed.add(element);

          }


        }


      }
    });
    
    notifyListeners();


   }
   getUserFeeds() async{
    feeds = await  _firebaseService.getUserPosts(details.feeds);
   }

  sendMessage(context) async{
   Navigator.push(context, MaterialPageRoute(builder: (context) {
          return PersonalMessageView( details: details,);
        }));

  }

  hireUser(context, summary, title) async{
    log('here');
    await _firebaseService.hireUser(details.name, details.uid, summary, title).whenComplete(() => goBack());

  }
  Future showHireDialog(context, dialog) async {
  final result = await Navigator.of(context).push(new MaterialPageRoute<ExperienceDetails>(
      builder: (BuildContext context) {
        return dialog;
      },
    fullscreenDialog: true
  ));
  if (result != null) {
    experience.add(result);
  }
  notifyListeners();
}
followUser() async {
  isFollowing = await _firebaseService.followUser(details);
  notifyListeners();

}


  
}