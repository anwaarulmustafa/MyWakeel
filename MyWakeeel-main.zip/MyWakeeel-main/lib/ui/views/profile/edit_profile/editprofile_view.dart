import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/models/certification_details.dart';
import 'package:mywakeel/models/experience_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'editprofile_viewmodel.dart';

class EditProfileView extends StatelessWidget {
  final nameController = TextEditingController(text: AppRepo.currentUserDetails!.name);
  final genderController = TextEditingController(text: AppRepo.currentUserDetails!.gender);
  final emailController = TextEditingController(text: AppRepo.currentUserDetails!.email);
  final courtController = TextEditingController(text: AppRepo.currentUserDetails!.court);
  final cityController = TextEditingController(text: AppRepo.currentUserDetails!.city);
  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<EditProfileViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
          key:scaffoldKey,
            appBar: AppBar(
            title: Text('Edit Profile'),
            actions: [
              IconButton(
                icon: Icon(Icons.save),
                onPressed: (){
                  model.save(nameController.text, courtController.text,
                  cityController.text, context, scaffoldKey);
                },
              )
            ],
            ),
            body: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                 Padding(
                   padding: const EdgeInsets.all(8.0),
                   child: InkWell(
                     onTap: (){
                       model.pickImage();
                     },
                     child: Container(
                            height: MySize.xMargin(context, 30),
                            width: MySize.xMargin(context, 30),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              image:  AppRepo.currentUserDetails!.imageUrl !=null?
                               DecorationImage(
                                 fit: BoxFit.cover,
                                image: 
                                NetworkImage(AppRepo.currentUserDetails!.imageUrl!),
                              ):  model.image !=null? 
                              DecorationImage(
                                 fit: BoxFit.cover,
                                image:  FileImage(File(model.image)),
                              ):
                               DecorationImage(
                                 fit: BoxFit.cover,
                                image: AssetImage("assets/images/icon.png",),
                              ),
                                ),
                            
                            child: Center(
                              child: Container(
                                  height: MySize.xMargin(context, 15),
                              width: MySize.xMargin(context, 15),
                              decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(50),
                                
                              ),
                                child: Icon(Icons.camera_alt),
                              ),
                            ),
                          ),
                   ),
                 ),
                      smallHeight(context),
                      customTextField(controller: nameController, hintText: 'Name'),
                      customTextField(
                        isEnabled: false,
                        controller: emailController, hintText: 'Email'),
                      customTextField(
                        isEnabled: false,controller: genderController, hintText: 'Gender'),
                      customTextField(controller: courtController, hintText: 'Court'),
                      customTextField(controller: cityController, hintText: 'City'),
                     

              Visibility(
                visible: AppRepo.isLawyer!,
                child: Column(
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height:  MySize.yMargin(context, 5),
                              child :  Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                  "Experience",
                                  style: TextStyle(
                                      fontSize: MySize.textSize(context, 6),
                                      fontWeight: FontWeight.w500),
                            ),
                            IconButton(
                              icon:Icon(Icons.add),
                              onPressed:(){
                                model.showExpDiaolg(context, ExperienceItem());
                              }
                            ),
                                ],
                              ),
                            ),
                           
                            Visibility(
                              visible: model.experience.length ==0,
                              replacement:  ListView.builder(
                                padding: EdgeInsets.zero,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: model.experience.length,
                                  itemBuilder: (context, index) {
                                    final exp = model.experience[index];
                                    return  Dismissible(
                        key: UniqueKey(), 
                        background: Container(
                          color: Colors.red,
                        ),
                        onDismissed: (direction){
                          model.removeExp(index);
                        },
                        child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Divider(color: Colors.grey[400]),
                                      smallHeight(context),
                                      Text(
                                        "${exp.jobTitle} | ${exp.clients} ",
                                        style: TextStyle(
                                            fontSize: MySize.textSize(context, 5),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      smallHeight(context),
                                      Text(
                                        "${exp.date}",
                                        style: TextStyle(
                                            fontSize: MySize.textSize(context, 4),
                                            fontWeight: FontWeight.w300),
                                      ),
                                      smallHeight(context),
                                      Text(
                                        "${exp.summary}",
                                        style: TextStyle(
                                            fontSize: MySize.textSize(context, 4),
                                            fontWeight: FontWeight.w400),
                                      ),
                                    ],
                                  ),
                        );
                                   
                                  }) ,
                              child: Container(
                                height: MySize.yMargin(context, 15),
                                child: Center(child: Text('Add an experience'))),
                            ),
                          ],
                        ),
                      ),
                    ),
                  

                 Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                          Container(
                          height:  MySize.yMargin(context, 5),
                          child :  Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                              "Certifications",
                              style: TextStyle(
                                  fontSize: MySize.textSize(context, 6),
                                  fontWeight: FontWeight.w500),
                        ),
                        IconButton(
                          icon:Icon(Icons.add),
                          onPressed:(){
                            model.showCertDiaolg(context, CertificationItem());
                          }
                        ),
                            ],
                          ),
                        ),
                        
                       
                        Visibility(
                          visible: model.certificates.length ==0,
                          replacement:  ListView.builder(
                            padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: model.certificates.length,
                              itemBuilder: (context, index) {
                                final exp = model.certificates[index];
                                return  Dismissible(
                    key: UniqueKey(), 
                    background: Container(
                      color: Colors.red,
                    ),
                    onDismissed: (direction){
                      model.removeCert(index);
                    },
                    child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Divider(color: Colors.grey[400]),
                                  smallHeight(context),
                                  Text(
                                    "${exp.title}",
                                    style: TextStyle(
                                        fontSize: MySize.textSize(context, 5),
                                        fontWeight: FontWeight.w500),
                                  ),
                                  smallHeight(context),
                                  Text(
                                    "${exp.date}",
                                    style: TextStyle(
                                        fontSize: MySize.textSize(context, 4),
                                        fontWeight: FontWeight.w300),
                                  ),
                                ],
                              ),
                    );
                               
                              }) ,
                          child: Container(
                            height: MySize.yMargin(context, 15),
                            child: Center(child: Text('Add a certificate'))),
                        ),
                      ],
                    ),
                  ),
                ),
            
                  ],
                ),
              ),],
          )),
        );
      }, 
      onModelReady: (model){
        model.onReady();
      },
      viewModelBuilder: ()=>EditProfileViewModel()) ;
  }
 

  

 
}


class ExperienceItem extends StatefulWidget{

  @override
  _ExperienceItemState createState() => _ExperienceItemState();
}

class _ExperienceItemState extends State<ExperienceItem> {
    final TextEditingController job = new TextEditingController();

    final TextEditingController client = new TextEditingController();

    final TextEditingController summary = new TextEditingController();

    final TextEditingController date = new TextEditingController();
    
    final _formKey = GlobalKey<FormState>();

    @override
    Widget build(BuildContext context) {
      return   Scaffold(
        appBar: AppBar(
           title:  Text('Add Experience'),
        actions: [
           InkWell(
              onTap: () {
                if(_formKey.currentState!.validate()){
                         Navigator
                    .of(context)
                    .pop(new ExperienceDetails(
                      clients: client.text,
                      date: date.text,
                      summary: summary.text,
                      jobTitle: job.text,

                    ));

                }
              
              },
              child: Center(child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('SAVE', style: TextStyle(color: appColor)),
              ))),
        ],
        ), 
        body: Form(
          key: _formKey,
          child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    customTextField(controller: job, hintText: 'Job Title'),
                                    customTextField(controller: client, hintText: 'Client\Court'),
                                    customTextField(controller: date, hintText: 'Date'),
                                    customTextField(controller: summary, hintText: 'Summary'),
                                   
                                  ],
                                ),
        ),
      );
    }
}

class CertificationItem extends StatefulWidget {
  @override
  _CertificationItemState createState() => _CertificationItemState();
}

class _CertificationItemState extends State<CertificationItem> {
  final TextEditingController cert = new TextEditingController();


    final TextEditingController date = new TextEditingController();
    final _formKey = GlobalKey<FormState>();

    @override
    Widget build(BuildContext context) {
      return   Scaffold(
        appBar: AppBar(
           title:  Text('Add Certifications'),
        actions: [
           InkWell(
              onTap: () {
                if(_formKey.currentState!.validate()){
                      Navigator
                    .of(context)
                    .pop(new CertificationsDetails(
                      title: cert.text,
                      date: date.text,

                    ));
                }
              
              },
              child: Center(child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('SAVE', style: TextStyle(color: appColor)),
              ))),
        ],
        ), 
        body: Form(
          key: _formKey,
          child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    customTextField(controller: cert, hintText: 'Certicate Issuer'),
                                    customTextField(controller: date, hintText: 'Date Issued'),
                                   
                                  ],
                                ),
        ),
      );
    }
}
