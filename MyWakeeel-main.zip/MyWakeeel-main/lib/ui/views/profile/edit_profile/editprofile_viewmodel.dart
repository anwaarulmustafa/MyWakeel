import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/models/certification_details.dart';
import 'package:mywakeel/models/experience_details.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';


class EditProfileViewModel extends BaseViewModel{
  
  List<ExperienceDetails> experience=[];
  List<CertificationsDetails> certificates=[];
  AuthenticationService _authenticationService = locator<AuthenticationService>();
  NavigationService _navigationService = locator<NavigationService>();
  var image;
   
  goBack()=> _navigationService.back();
  onReady(){
    experience = AppRepo.currentUserDetails!.experience as List<ExperienceDetails>;
    // certificates = AppRepo.currentUserDetails.cetifications??[];
    notifyListeners();
  }

  logout(){

    _authenticationService.signOut();

  }
  navigateToSettings(){
    _navigationService.navigateTo(Routes.mainView);

  }


   removeExp(index){
      experience.removeAt(index);
      notifyListeners();
   }
    removeCert(index){
      certificates.removeAt(index);
      notifyListeners();
   }
 
 Future showExpDiaolg(context, dialog) async {
  final result = await Navigator.of(context).push(new MaterialPageRoute<ExperienceDetails>(
      builder: (BuildContext context) {
        return dialog;
      },
    fullscreenDialog: true
  ));
  if (result != null) {
    experience.add(result);
  }
  notifyListeners();
}
Future showCertDiaolg(context, dialog) async {
  final result = await Navigator.of(context).push(new MaterialPageRoute<CertificationsDetails>(
      builder: (BuildContext context) {
        return dialog;
      },
    fullscreenDialog: true
  ));
  if (result != null) {
    certificates.add(result);
  }
  notifyListeners();
}


pickImage() async {
FilePickerResult result = (await FilePicker.platform.pickFiles(
  type: FileType.image,
  allowCompression: true,
  ))!;

if(result.files.single.path !=null) {
   image = result.files.single.path;
   notifyListeners();
}


}

Future<void> save(name, court, city, context, key) async {
  

await _authenticationService.updateUserDetail(name: name, url: image, context:context, 
scaffoldKey: key,court: court, city: city, experience: experience,
 cetifications: certificates );
}


}