import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/views/profile/viewprofile_view/viewfollows.dart';
import 'package:stacked/stacked.dart';

import 'profile_viewmodel.dart';

class ProfileView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ProfileViewModel>.reactive(
        builder: (context, model, child) {
           if(AppRepo.isLawyer!){
          return _lawyerProfileScreen(model, context);
           }else{
             
           return _clientProfileScreen(model, context);

           }
        },
        onModelReady: (model){
          model.onReady();
        },
        viewModelBuilder: () => ProfileViewModel());
  }

  Widget header(ProfileViewModel model, context){
    return Column(
      children: [
          SafeArea(
                child: Padding(
                  padding: EdgeInsets.only(left: 16, right: 16, top: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        "Profile",
                        style: TextStyle(
                            fontSize: MySize.textSize(context, 9),
                            fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          icon: Icon(Icons.settings, color: appColor),
                          onPressed: model.navigateToSettings)
                    ],
                  ),
                ),
              ),
              smallHeight(context),
              Card(child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                       Container(
                            height: MySize.xMargin(context, 30),
                            width: MySize.xMargin(context, 30),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              image:  AppRepo.currentUserDetails!.imageUrl !=null?
                               DecorationImage(
                                 fit: BoxFit.cover,
                                image: 
                                NetworkImage(AppRepo.currentUserDetails!.imageUrl!),
                              ): 
                               DecorationImage(
                                 fit: BoxFit.cover,
                                image: AssetImage("assets/images/icon.png",),
                              ),
                                ),
                          ),
                      minHeight(context),
                      Text("${AppRepo.currentUserDetails!.name}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 26.0,
                              fontWeight: FontWeight.bold)),
                      Text(
                        "${AppRepo.currentUserDetails!.email}",
                        style: TextStyle(
                            color: Colors.grey,
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold),
                      ),
                      Text("${AppRepo.currentUserDetails!.gender}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15.0,
                              fontWeight: FontWeight.normal)),

                      Visibility(
                        visible: AppRepo.isLawyer!,
                        child: Text(
                          "${AppRepo.currentUserDetails!.court}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Text("${AppRepo.currentUserDetails!.city}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15.0,
                              fontWeight: FontWeight.normal)),
                              Divider(),
                              smallHeight(context),
                              Visibility(
                        visible: AppRepo.isLawyer!,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: (){
                                Navigator.of(context)
                                .push(CupertinoPageRoute(builder: (context)=> ViewFollows(AppRepo.currentUserDetails!, true)));
                              },
                              child: Text('${NumberFormat.compact().format(double.parse('${AppRepo.currentUserDetails!.followers!.length}'))}\n Followers',
                              textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 4.5),)),
                            ),InkWell(
                              onTap: (){
                                 Navigator.of(context)
                                .push(CupertinoPageRoute(builder: (context)=> ViewFollows(AppRepo.currentUserDetails!, false)));
                              },
                              child: Text('${NumberFormat.compact().format(double.parse('${AppRepo.currentUserDetails!.follows!.length}'))}\n Following',
                              textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 4.5),)),
                            ),
                          ],
                        )),
                    ],
                  ),
                ),
              ),
              ),
      ],
    );
  }


  Widget _lawyerProfileScreen( ProfileViewModel model, context) {
    return Scaffold(
     
      body: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               header(model, context),
                      
               
            

              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: 
                            Text(
                            "Experience",
                            style: TextStyle(
                                fontSize: MySize.textSize(context, 6),
                                fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                     
                      Visibility(
                        visible: model.experience.length ==0,
                        replacement:  ListView.builder(
                          padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: model.experience.length,
                            itemBuilder: (context, index) {
                              final exp = model.experience[index];
                              return  Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Divider(color: Colors.grey[400]),
                                            smallHeight(context),
                                            Text(
                                              "${exp.jobTitle} | ${exp.clients} ",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 5),
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.date}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w300),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.summary}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w400),
                                            ),
                                          ],
                                        );
                             
                            }) ,
                        child: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(child: Text('Add an experience'))),
                      ),
                    ],
                  ),
                ),
              ),
               Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                          "Completed Jobs",
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 6),
                              fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                       Visibility(
                        visible: model.experience.length ==0,
                        replacement:  ListView.builder(
                          padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: model.experience.length,
                            itemBuilder: (context, index) {
                              final exp = model.experience[index];
                              return  Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Divider(color: Colors.grey[400]),
                                            smallHeight(context),
                                            Text(
                                              "${exp.jobTitle} | ${exp.clients} ",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 5),
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.date}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w300),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.summary}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w400),
                                            ),
                                          ],
                                        );
                             
                            }) ,
                        child: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(child: Text('Add an experience'))),
                      ),
                   
                    ],
                  ),
                ),
              ),

                 Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Container(
                        height:  MySize.yMargin(context, 5),
                        child :  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                          "Certifications",
                          style: TextStyle(
                              fontSize: MySize.textSize(context, 6),
                              fontWeight: FontWeight.w500),
                      ),
                        ),
                      ),
                      
                     
                      Visibility(
                        visible: model.certificates.length ==0,
                        replacement:  ListView.builder(
                          padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: model.certificates.length,
                            itemBuilder: (context, index) {
                              final exp = model.certificates[index];
                              return  Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "${exp.title}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 5),
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            smallHeight(context),
                                            Text(
                                              "${exp.date}",
                                              style: TextStyle(
                                                  fontSize: MySize.textSize(context, 4),
                                                  fontWeight: FontWeight.w300),
                                            ),
                                          ],
                                        );
                             
                            }) ,
                        child: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(child: Text('Add a certificate'))),
                      ),
                    ],
                  ),
                ),
              ),
              
            ],
          )),
    );
  }

  Widget _clientProfileScreen(model, context) {
    return Scaffold(
      body: SingleChildScrollView(
          child: header(model, context)),
    );
  }
}
