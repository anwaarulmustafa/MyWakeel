
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/models/certification_details.dart';
import 'package:mywakeel/models/experience_details.dart';
import 'package:mywakeel/services/authentication_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class ProfileViewModel extends BaseViewModel {
  AuthenticationService _authenticationService =
      locator<AuthenticationService>();
  NavigationService _navigationService = locator<NavigationService>();
  
  List<ExperienceDetails> experience=[];
  List<CertificationsDetails> certificates=[];
  onReady(){
    experience = AppRepo.currentUserDetails!.experience!;
    certificates = AppRepo.currentUserDetails!.cetifications!;
    notifyListeners();

  }

  goBack() => _navigationService.back();

  logout() {
    _authenticationService.signOut();
  }

  navigateToSettings() async {
    await _navigationService.navigateTo(Routes.settingsView);
    notifyListeners();
  }
 
}
