import 'package:file_picker/file_picker.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class CreatePostViewModel extends BaseViewModel {
  NavigationService _navigationService = locator<NavigationService>();
  FirebaseService _firebaseService = locator<FirebaseService>();
  var media;
  bool containsImage = false, containsVideo = false;
   goBack() => _navigationService.back();

 createPost(text) async {
   goBack();
     _firebaseService.createPost(
      media: media,
     text: text.trim(),
      containsImage: containsImage,
      containsVideo: containsVideo,
     );
  }

  pickImage() async {
    FilePickerResult result = (await FilePicker.platform.pickFiles(
      type: FileType.image
    ))!;

    if (result.files.single.path != null) {
      //  File file = File(result.files.single.path);
      media = result.files.single.path;
      containsImage = true;
    } 
    
    notifyListeners();
  }

   pickVideo() async {
    FilePickerResult result = (await FilePicker.platform.pickFiles(
      type: FileType.video
    ))!;

    if (result.files.single.path != null) {
      //  File file = File(result.files.single.path);
      media = result.files.single.path;
      containsVideo = true;
    } 
    
    notifyListeners();
  }
 cancel() {
    media = null;
    containsImage = containsVideo = false;
    notifyListeners();
  }
}
