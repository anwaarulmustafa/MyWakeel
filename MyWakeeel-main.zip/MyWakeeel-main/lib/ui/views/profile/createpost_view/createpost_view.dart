import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';
import 'createpost_viewmodel.dart';

class CreatePostView extends StatelessWidget {
  final controller = TextEditingController();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CreatePostViewModel>.reactive(
      builder: (context, model, child){
         return Scaffold(
           key: scaffoldKey,
          appBar: AppBar(
            title: Text('Create Post'),
            actions: [
              Center(
                child: TextButton(
                  child: Text('Post'),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(appColor),
                    minimumSize: MaterialStateProperty.all<Size>(Size.zero),
                    textStyle: MaterialStateProperty.all(
                      TextStyle(color: Colors.white),
                    ),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                    padding: MaterialStateProperty.all(EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    )),
                    shape: MaterialStateProperty.all<OutlinedBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                  onPressed: () async {
                     model.createPost(controller.text);
                  },
                ),
              ),
              smallWidth(context),
            ],
          ),
          body: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextField(
                  maxLines: null,
                  expands: false,
                  controller: controller,
                   decoration: InputDecoration(
                     hintText: 'Type something here...',
                      contentPadding: EdgeInsets.all(12),
                      
                      // focusedBorder: OutlineInputBorder(
                      //   borderSide: BorderSide(color: appColor)

                      // ),
                       border: InputBorder.none,
                    ),
                ),
                Expanded(
                  child: Center(
                    child: Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: model.containsImage
                              ? Image.file(File(model.media))
                              : Container(),
                        ),
                        Visibility(
                          visible: model.media != null,
                          replacement: Container(),
                          child: IconButton(
                            onPressed: model.cancel,
                            icon: Icon(Icons.cancel),
                            iconSize: 30,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // Visibility(
                //   visible: model.containsImage,
                //   replacement: Container(),
                //   child: Container(
                //     child: Stack(
                //       children: [
                //         IconButton(
                //           onPressed: model.cancel,
                //           icon: Icon(Icons.cancel),
                //         ),
                //         Image(
                //           image: FileImage(File(model.media ?? '')),
                //         ),
                //       ],
                //     ),
                //   ),
                // ),
                FittedBox(
                  fit: BoxFit.cover,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: model.pickImage,
                        child: Icon(Icons.image),
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all<Color>(appColor),
                          padding: MaterialStateProperty.all(
                            EdgeInsets.symmetric(
                              horizontal: MySize.xMargin(context, 25),
                              vertical: MySize.yMargin(context, 3),
                            ),
                          ),
                        ),
                      ),
                      // ElevatedButton(
                      //   onPressed: model.pickImage,
                      //   child: Icon(Icons.video_call),
                      //   style: ButtonStyle(
                      //     backgroundColor:
                      //         MaterialStateProperty.all<Color>(appColor),
                      //     padding: MaterialStateProperty.all(
                      //       EdgeInsets.symmetric(
                      //         horizontal: MySize.xMargin(context, 25),
                      //         vertical: MySize.yMargin(context, 3),
                      //       ),
                      //     ),
                      //   ),
                      // ),
                    ],
                  ),
                ),
                smallHeight(context),
              ],
            ),
          ),
        );
      }, 
      viewModelBuilder: ()=>CreatePostViewModel());
  }
}