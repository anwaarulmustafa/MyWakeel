import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/shared/feed_card.dart';
import 'package:mywakeel/ui/views/home_view/home_viewmodel.dart';
import 'package:stacked/stacked.dart';


class HomeView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomeViewModel>.reactive(
        builder: (context, model, child) {
          if (AppRepo.isLawyer!) {
            return LawyerHomeView();
          } else {
            return ClientHomeView();
          }
        },
        viewModelBuilder: () => HomeViewModel());
  }
}

class LawyerHomeView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomeViewModel>.reactive(
        builder: (context, model, child) {
          return Scaffold( 
            floatingActionButton: FloatingActionButton(
        backgroundColor: appColor,
        onPressed:()=> model.navigateToCreateNewPost(),
        child: Icon(Icons.add),
      ),
            body: Column(
              children: [
             
                SafeArea(
                  child: Padding(
                    padding: EdgeInsets.only(left: 16, right: 16, top: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        iconHeader(context, 12),
                      ],
                    ),
                  ),
                ),
                showBusy(model),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: ListView(children: [
                      Card(
                        child: Container(
                          color: appColor,
                          height: MySize.yMargin(context, 15),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: InkWell(
                                      onTap:()=> model.navigateToCaseHistory(),
                                      child: Container(
                                        child: Center(
                                            child: Text(
                                          'Case History',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize:
                                                  MySize.textSize(context, 6)),
                                        )),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child:
                                        Container(width: 2, color: Colors.white),
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      onTap:()=> model.navigateToCaseRequest(),
                                      child: Container(
                                        child: Center(
                                            child: Text(
                                          'Case Request',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize:
                                                  MySize.textSize(context, 6)),
                                        )),
                                      ),
                                    ),
                                  ),
                                ]),
                          ),
                        ),
                      ),
                      smallHeight(context),
                      Text(
                        'Popular Lawyers',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: MySize.textSize(context, 6.5),
                        ),
                      ),
                      smallHeight(context),
                       Visibility(
                         visible: model.popularLawyers.length !=0,
                         child: Container(
                          height: MySize.yMargin(context, 30),
                          child: ListView.builder(
                            itemCount: model.popularLawyers.length,
                             scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index){

                              return customItem(model.popularLawyers[index], context);


                            }),
                      ),
                       ),
                      smallHeight(context),
                      
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Your Newsfeed',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: MySize.textSize(context, 6.5),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              model.navigateToLawyersfeed();
                            },
                            child: Text(
                              'See All',
                              style: TextStyle(
                                fontSize: MySize.textSize(context, 5.5),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Visibility(
            visible: model.feeds.length!=0,
            replacement: Container(),
            child:
             ListView.builder(
               shrinkWrap: true,
               physics: NeverScrollableScrollPhysics(),
                  itemCount: model.feeds.length <10?model.feeds.length:10,
                  itemBuilder: (context, index) {
                    final feed = model.feeds[index];
                    return 
                     FeedCard(feed: feed, );
                  },
                ),
          ),
                      ]),
                  ),
                ),
              ],
            ),
          );
        },
        onModelReady: (model){
          model.onReady();
        },
        viewModelBuilder: () => HomeViewModel());
  }
}

class ClientHomeView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomeViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
          body: Column(children: [
      SafeArea(
          child: Padding(
            padding: EdgeInsets.only(left: 16, right: 16, top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                iconHeader(context, 12),
                IconButton(
                    icon: Icon(Icons.apps, color: appColor), onPressed: () {
                      model.navigateToCaseHistory();
                    })
              ],
            ),
          ),
      ),
      Expanded(
        child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  smallHeight(context),
                  InkWell(
                    onTap: () {
                      model.navigateToLawyersSearch();
                    },
                    child: Card(
                      elevation: 6,
                      child: Padding(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.search,
                              color: Colors.grey[500],
                            ),
                            smallWidth(context),
                            Text(
                              'What are you searching for?',
                              style: TextStyle(
                                fontSize: MySize.textSize(context, 4.5),
                                color: Colors.grey[500],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  smallHeight(context),
                  Text(
                    'Popular Lawyers',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 6.5),
                    ),
                  ),smallHeight(context),
                           Visibility(
                             visible: model.popularLawyers.length !=0,
                             child: Container(
                              height: MySize.yMargin(context, 30),
                              child: ListView.builder(
                                itemCount: model.popularLawyers.length,
                                 scrollDirection: Axis.horizontal,
                                itemBuilder: (context, index){

                                  return customItem(model.popularLawyers[index], context);


                                }),
                          ),
                           ),
                          smallHeight(context),
                          
                  smallHeight(context),
                  Text(
                    'Lawyers around you ',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 6.5),
                    ),
                  ),     Visibility(
                             visible: model.aroundLawyers.length !=0,
                             child: Container(
                              height: MySize.yMargin(context, 30),
                              child: ListView.builder(
                                itemCount: model.aroundLawyers.length,
                                 scrollDirection: Axis.horizontal,
                                itemBuilder: (context, index){

                                  return customItem(model.aroundLawyers[index], context);


                                }),
                          ),
                           ),
                ],
              ),
            ),
        ),
      )
    ]),
        );
    }, 
    onModelReady: (model){
      model.onClientReady();
    },
      viewModelBuilder: ()=> HomeViewModel());
  }
}
