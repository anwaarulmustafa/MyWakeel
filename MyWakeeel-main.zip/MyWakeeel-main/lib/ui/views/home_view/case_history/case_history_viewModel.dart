import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:mywakeel/models/hire_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';
class CaseHistoryViewModel extends BaseViewModel{

   NavigationService _navigationService = locator<NavigationService>();
   
  List<HireDetails> completed =[];
  List<HireDetails> inProgress =[];
  List<HireDetails> pending =[];
  FirebaseService _firebaseService = locator<FirebaseService>();
   bool isCompletedExpanded= false, isProgressExpanded= false, isPending =false;
  goBack()=> _navigationService.back();

  navigateToForgotPassword(){
    _navigationService.navigateTo(Routes.caseHistoryView);

  }
   getHires() async {
    final hire = await _firebaseService.getHires();
    hire.forEach((element) { 
      if(element.hiredUserId == AppRepo.currentUserDetails!.uid){
        if(element.isReacted!){
          if(element.isAccepted! &&element.inCompleted!){
            completed.add(element);

          }else if(element.isAccepted! &&element.inProgress!){
            inProgress.add(element);

          }


        }


      }
    });
    
    notifyListeners();


   }
   getHired() async {
       final hire = await _firebaseService.getHires();
    hire.forEach((element) { 
      if(element.hiredById == AppRepo.currentUserDetails!.uid){
        if(element.isReacted!){
          if(element.isAccepted! &&element.inCompleted!){
            completed.add(element);

          }else if(element.isAccepted! &&element.inProgress!){
            inProgress.add(element);

          }


        }else{
          pending.add(element);
        }


      }
    });
    
    notifyListeners();



   }

     updateCompleted(){
     if(isCompletedExpanded ==true){
       isCompletedExpanded =false;

     }else{
       isCompletedExpanded = true;

     }
     
    notifyListeners();


   }
    updateProgress(){
     if(isProgressExpanded ==true){
       isProgressExpanded =false;

     }else{
       isProgressExpanded = true;

     }
     
    notifyListeners();


   }

    updatePending(){
     if(isPending ==true){
       isPending =false;

     }else{
       isPending = true;

     }
     
    notifyListeners();


   }
   

   reactToHireCompleted(HireDetails hire) async {
     await _firebaseService.updateHireUserCompleted(hire);
     await getHires();

   }

  
}