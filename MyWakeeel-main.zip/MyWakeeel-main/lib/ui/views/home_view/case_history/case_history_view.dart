import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_text.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/views/home_view/case_history/case_history_viewModel.dart';
import 'package:stacked/stacked.dart';


class CaseHistoryView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CaseHistoryViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
          appBar: AppBar(
            iconTheme: IconThemeData(
              color: Colors.white
            ),
            backgroundColor: appColor,
            title: Text("Case History",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                      ),
          ),
        body: Visibility(
          visible: AppRepo.isLawyer!,
          replacement: _clientView(model, context),
          child: _lawyerView(model, context)),
    //      Column(
    //   children:[
    //      smallHeight(context),
    //         Card(
    //             child: ListTile(
    //               leading: Text(
    //                 'Completed (${model.completed.length})',
    //                 style: TextStyle(
    //                   fontSize: MySize.textSize(context, 6),
    //                   fontWeight: FontWeight.bold,
    //                 ),
    //               ),
    //               trailing: Visibility(
    //                 visible: model.completed.length!=0,
    //                 child: IconButton(
    //                   onPressed: model.updateCompleted,
    //                   icon: Icon(model.isCompletedExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
    //                 )),
    //             ),
    //           ),
    //            ExpandableContainer(
    //           isExpanded: model.isCompletedExpanded,
    //           collapsedchild: Container(),
    //           expandedChild: ListView.builder( shrinkWrap: true,
    //               physics: NeverScrollableScrollPhysics(),
    //               itemCount: model.completed.length,
    //               itemBuilder: (context, index) {
    //             final hire = model.completed.reversed.toList()[index];
    //             return Padding(
    //               padding: const EdgeInsets.all(10.0),
    //               child: Column(
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //               children: [
    //               Text(
    //                 '${hire.hiredBy} hired you for ${hire.jobTitle}',
    //                 style: TextStyle(
    //                   fontWeight: FontWeight.bold,
    //                   fontSize: MySize.textSize(context, 5.5),
    //                 ),
    //               ),
    //               minHeight(context),Text(
    //                 '${hire.summary}',
    //                 style: TextStyle(
    //                   fontWeight: FontWeight.bold,
    //                   fontSize: MySize.textSize(context, 5.5),
    //                 ),
    //               ),
    //               minHeight(context),
    //                Text(formatDate('${hire.dateHired}'),
    //                   style: TextStyle(
    //                     color: Colors.grey[600],
    //                     fontSize: MySize.textSize(context, 4.5),
    //                   ),
    //                 ),
    //               minHeight(context),
    //                 hire.dateUpdated != null?Text(formatDate('Completed - ${hire.dateUpdated }'),
    //                 style: TextStyle(
    //                   color: Colors.grey[600],
    //                   fontSize: MySize.textSize(context, 4),
    //                 ),
    //               ):Container(),
                      
    //               Divider(),
    //               ],
    //             ),
    //             );
    //           }),
    //         ),
            
             
    //           Card(
    //             child: ListTile(
    //               leading: Text(
    //                 'In Progress (${model.inProgress.length})',
    //                 style: TextStyle(
    //                   fontSize: MySize.textSize(context, 6),
    //                   fontWeight: FontWeight.bold,
    //                 ),
    //               ),
    //               trailing: Visibility(
    //                 visible: model.inProgress.length!=0,
    //                 child: IconButton(
    //                   onPressed: model.updateProgress,
    //                   icon: Icon(model.isProgressExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
    //                 )),
    //             ),
    //           ),
    //            ExpandableContainer(
    //           isExpanded: model.isProgressExpanded,
    //           collapsedchild: Container(),
    //           expandedChild: ListView.builder( shrinkWrap: true,
    //               physics: NeverScrollableScrollPhysics(),
    //               itemCount: model.inProgress.length,
    //               itemBuilder: (context, index) {
    //             final hire = model.inProgress.reversed.toList()[index];
    //             return Padding(
    //               padding: const EdgeInsets.all(10.0),
    //               child: Column(
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //               children: [
    //               Text(
    //                 '${hire.hiredBy} hired you for ${hire.jobTitle}',
    //                 style: TextStyle(
    //                   fontWeight: FontWeight.bold,
    //                   fontSize: MySize.textSize(context, 5.5),
    //                 ),
    //               ),
    //               minHeight(context),Text(
    //                 '${hire.summary}',
    //                 style: TextStyle(
    //                   fontWeight: FontWeight.bold,
    //                   fontSize: MySize.textSize(context, 5.5),
    //                 ),
    //               ),
    //               minHeight(context),
    //                Text(formatDate('${hire.dateHired}'),
    //                   style: TextStyle(
    //                     color: Colors.grey[600],
    //                     fontSize: MySize.textSize(context, 4.5),
    //                   ),
    //                 ),
    //               minHeight(context),
    //               Container(
    //                 height: 60,
    //                 width: double.infinity,
    //                 child: ElevatedButton(
    //                   style: ElevatedButton.styleFrom(
    //                     primary: appColor,
    //                   ),
    //                     onPressed: () {
    //                       model.reactToHireCompleted(hire);
    //                     },
    //                     child: Text('Mark as Completed')),
    //               ),
    //                   minHeight(context),
                      
    //               Divider(),
    //               ],
    //             ),
    //             );
    //           }),
    //         ),
            
     
         
    //   ]
    // ),
        );
      },
      onModelReady: (model){
        if(AppRepo.isLawyer!){
        model.getHires();

        }else{
          model.getHired();
        }
      },
      viewModelBuilder: ()=> CaseHistoryViewModel(),
      );
      }

      Widget _lawyerView(CaseHistoryViewModel model, context){
        return Column(
      children:[
         smallHeight(context),
            Card(
                child: ListTile(
                  leading: Text(
                    'Completed (${model.completed.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.completed.length!=0,
                    child: IconButton(
                      onPressed: model.updateCompleted,
                      icon: Icon(model.isCompletedExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    )),
                ),
              ),
               ExpandableContainer(
              isExpanded: model.isCompletedExpanded,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.completed.length,
                  itemBuilder: (context, index) {
                final hire = model.completed.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    '${hire.hiredBy} hired you for ${hire.jobTitle}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),Text(
                    '${hire.summary}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                   Text(formatDate('${hire.dateHired}'),
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: MySize.textSize(context, 4.5),
                      ),
                    ),
                  minHeight(context),
                    hire.dateUpdated != null?Text(formatDate('Completed - ${hire.dateUpdated }'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ):Container(),
                      
                  Divider(),
                  ],
                ),
                );
              }),
            ),
            
             
              Card(
                child: ListTile(
                  leading: Text(
                    'In Progress (${model.inProgress.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.inProgress.length!=0,
                    child: IconButton(
                      onPressed: model.updateProgress,
                      icon: Icon(model.isProgressExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    )),
                ),
              ),
               ExpandableContainer(
              isExpanded: model.isProgressExpanded,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.inProgress.length,
                  itemBuilder: (context, index) {
                final hire = model.inProgress.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    '${hire.hiredBy} hired you for ${hire.jobTitle}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),Text(
                    '${hire.summary}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                   Text(formatDate('${hire.dateHired}'),
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: MySize.textSize(context, 4.5),
                      ),
                    ),
                  minHeight(context),
                  Container(
                    height: 60,
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: appColor,
                      ),
                        onPressed: () {
                          model.reactToHireCompleted(hire);
                        },
                        child: Text('Mark as Completed')),
                  ),
                      minHeight(context),
                      
                  Divider(),
                  ],
                ),
                );
              }),
            ),
            
     
         
      ]
    );
      }
  
      Widget _clientView(CaseHistoryViewModel model, context){
        return Column(
      children:[
         smallHeight(context),
            Card(
                child: ListTile(
                  leading: Text(
                    'Completed (${model.completed.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.completed.length!=0,
                    child: IconButton(
                      onPressed: model.updateCompleted,
                      icon: Icon(model.isCompletedExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    )),
                ),
              ),
               ExpandableContainer(
              isExpanded: model.isCompletedExpanded,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.completed.length,
                  itemBuilder: (context, index) {
                final hire = model.completed.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    'You hired ${hire.hiredBy} for ${hire.jobTitle}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),Text(
                    '${hire.summary}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                   Text(formatDate('${hire.dateHired}'),
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: MySize.textSize(context, 4.5),
                      ),
                    ),
                  minHeight(context),
                    hire.dateUpdated != null?Text(formatDate('Completed - ${hire.dateUpdated }'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ):Container(),
                      
                  Divider(),
                  ],
                ),
                );
              }),
            ),
            
             
              Card(
                child: ListTile(
                  leading: Text(
                    'In Progress (${model.inProgress.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.inProgress.length!=0,
                    child: IconButton(
                      onPressed: model.updateProgress,
                      icon: Icon(model.isProgressExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    )),
                ),
              ),
               ExpandableContainer(
              isExpanded: model.isProgressExpanded,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.inProgress.length,
                  itemBuilder: (context, index) {
                final hire = model.inProgress.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    'You hired ${hire.hiredBy} for ${hire.jobTitle}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),Text(
                    '${hire.summary}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                   Text(formatDate('${hire.dateHired}'),
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: MySize.textSize(context, 4.5),
                      ),
                    ),
                  minHeight(context),
                  Container(
                    height: 60,
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: appColor,
                      ),
                        onPressed: () {
                          model.reactToHireCompleted(hire);
                        },
                        child: Text('Mark as Completed')),
                  ),
                      minHeight(context),
                      
                  Divider(),
                  ],
                ),
                );
              }),
            ),
             Card(
                child: ListTile(
                  leading: Text(
                    'Pending (${model.pending.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.pending.length!=0,
                    child: IconButton(
                      onPressed: model.updatePending,
                      icon: Icon(model.isPending?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    ))
                ),
              ),
              ExpandableContainer(
              isExpanded: model.isPending,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.pending.length,
                  itemBuilder: (context, index) {
                final refer = model.pending.reversed.toList()[index];
                
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    '${refer.hiredUser}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                 minHeight(context),
                  Text(formatDate('${refer.dateHired}'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ),
                 minHeight(context),
                   Visibility(
                        replacement: Text(refer.isAccepted!?'${refer.hiredUser } accepted this request':'${refer.hiredUser} rejected this request',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                    )),
                        visible: !refer.isReacted!,
                        child: Text(' Awaiting ${refer.hiredUser } reponse', style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                    )) 
                        ),
                  Divider(),
                  ],
                ),
                );
              }),
            ),
           
            
     
         
      ]
    );
      }
  
}
