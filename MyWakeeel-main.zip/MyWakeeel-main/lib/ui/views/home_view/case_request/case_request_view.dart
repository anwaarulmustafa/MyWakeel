import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_text.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';
import 'case_request_viewModel.dart';

class CaseRequestView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CaseRequestViewModel>.reactive(
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            iconTheme: IconThemeData(color: Colors.white),
            backgroundColor: appColor,
            title: Text(
              "Case Requests",
                    style: TextStyle(
                      color: Colors.white,
                    ),
            ),
          ),
          body: ListView(children: [
            smallHeight(context),
            Card(
                child: ListTile(
                  leading: Text(
                    'Hire Request (${model.hires.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.hires.length!=0,
                    child: IconButton(
                      onPressed: model.updateHire,
                      icon: Icon(model.isHiredExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    )),
                ),
              ),
               ExpandableContainer(
              isExpanded: model.isHiredExpanded,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.hires.length,
                  itemBuilder: (context, index) {
                final hire = model.hires.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    '${hire.hiredBy} wants to hire you for ${hire.jobTitle}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),Text(
                    '${hire.summary}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                   Text(formatDate('${hire.dateHired}'),
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: MySize.textSize(context, 4.5),
                      ),
                    ),
                  minHeight(context),
                  Visibility(
                      replacement:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(hire.isAccepted!?'You accepted this request':'You  rejected this request',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                    )),
                 minHeight(context),
                    hire.dateUpdated != null?Text(formatDate('${hire.dateUpdated }'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ):Container(),
                              ],
                            ),
                      visible: !hire.isReacted!,
                      child: Row(
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: appColor,
                            ),
                              onPressed: () {
                                model.reactToHire(hire, true);
                              },
                              child: Text('Accept')),
                          smallWidth(context),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: appColor,
                            ),
                              onPressed: () {
                                model.reactToHire(hire, false);
                              },
                              child: Text('Reject'))
                        ],
                      )),
                      minHeight(context),
                      
                  Divider(),
                  ],
                ),
                );
              }),
            ),
            
             Card(
                child: ListTile(
                  leading: Text(
                    'Refer Request (${model.reffered.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing:  Visibility(
                    visible: model.reffered.length!=0,
                    child: IconButton(
                      onPressed: model.updateRefer,
                      icon: Icon(model.isrefferedExpanded?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    )),
                ),
              ),
            ExpandableContainer(
              isExpanded: model.isrefferedExpanded,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.reffered.length,
                  itemBuilder: (context, index) {
                final refer = model.reffered.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    '${refer.refferedUser}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                  Text(
                    'Reffered by ${refer.refferedBy}',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                  minHeight(context),
                  Visibility(
                      replacement: refer.isAccepted!
                          ? Text('You accepted this request')
                          : Text('You rejected this request'),
                      visible: !refer.isReacted!,
                      child: Row(
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: appColor,
                            ),
                              onPressed: () {
                                model.reactToRequest(refer, true);
                              },
                              child: Text('Accept')),
                          smallWidth(context),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: appColor,
                            ),
                              onPressed: () {
                                model.reactToRequest(refer, false);
                              },
                              child: Text('Reject'))
                        ],
                      )),
                      minHeight(context),
                       Visibility(
                    visible: refer.dateAccepted!=null,
                    replacement: Text(formatDate('${refer.dateReffered }'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ),
                    child:  Text(formatDate('${refer.dateAccepted}'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ),),
                  Divider(),
                  ],
                ),
                );
              }),
            ),
            Card(
                child: ListTile(
                  leading: Text(
                    'Reffered (${model.myReffered.length})',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 6),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Visibility(
                    visible: model.myReffered.length!=0,
                    child: IconButton(
                      onPressed: model.updateMyRefer,
                      icon: Icon(model.ismyReffered?Icons.arrow_drop_up: Icons.arrow_drop_down),
                    ))
                ),
              ),
              ExpandableContainer(
              isExpanded: model.ismyReffered,
              collapsedchild: Container(),
              expandedChild: ListView.builder( shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: model.myReffered.length,
                  itemBuilder: (context, index) {
                final refer = model.myReffered.reversed.toList()[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Text(
                    '${refer.refferedUser}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: MySize.textSize(context, 5.5),
                    ),
                  ),
                 minHeight(context),
                  Text(formatDate('${refer.dateAccepted}'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ),
                 minHeight(context),
                   Visibility(
                        replacement: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(refer.isAccepted!?'${refer.refferedTo} accepted this request':'${refer.refferedTo} rejected this request',
                    style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                    )),
                 minHeight(context),
                    Text(formatDate('${refer.dateAccepted }'),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: MySize.textSize(context, 4),
                    ),
                  ),
                              ],
                            ),
                        visible: !refer.isReacted!,
                        child: Text(' Awaiting ${refer.refferedTo} reponse', style: TextStyle(
                      fontSize: MySize.textSize(context, 4),
                    )) 
                        ),
                  Divider(),
                  ],
                ),
                );
              }),
            ),
           
          ]),
        );
      },
      onModelReady:(model){
        model.onReady();
      },
      viewModelBuilder: () => CaseRequestViewModel(),
    );
  }
}
