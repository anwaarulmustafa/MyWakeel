import 'package:mywakeel/models/hire_details.dart';
import 'package:mywakeel/models/refer_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/core/app.locator.dart';
class CaseRequestViewModel extends BaseViewModel{
  
  FirebaseService _firebaseService = locator<FirebaseService>();
  List<HireDetails> hires =[];
  List<ReferDetails> reffered =[];
  List<ReferDetails> myReffered =[];
   bool isHiredExpanded= false, isrefferedExpanded= false, ismyReffered= false;
   onReady() async {
    await getReffered();
    await getHires();
    

   }
   getHires() async {
    final hire = await _firebaseService.getHires();
    hire.forEach((element) { 
      if(element.hiredUserId == AppRepo.currentUserDetails!.uid){
        hires.add(element);


      }
    });
    
    notifyListeners();


   }
   getReffered() async {
     final ref = await _firebaseService.getReffered();
     
    ref.forEach((e){
      if(e.refferedById == AppRepo.currentUserDetails!.uid){
        myReffered.add(e);
        reffered.add(e);

      }else{
        reffered.add(e);

      }

    });
    notifyListeners();

   }

   reactToRequest(ReferDetails refer, bool isAccepted) async {
     await _firebaseService.updateReferUser(isAccepted, refer);

   }
   reactToHire(HireDetails hire, bool isAccepted) async {
     await _firebaseService.updateHireUser(isAccepted,hire);

   }
   updateMyRefer(){
     if(ismyReffered ==true){
       ismyReffered =false;

     }else{
       ismyReffered = true;

     }
     
    notifyListeners();


   }
    updateRefer(){
     if(isrefferedExpanded ==true){
       isrefferedExpanded =false;

     }else{
       isrefferedExpanded = true;

     }
     
    notifyListeners();


   }
    updateHire(){
     if(isHiredExpanded ==true){
       isHiredExpanded =false;

     }else{
       isHiredExpanded = true;

     }
     
    notifyListeners();


   }
  
  
}