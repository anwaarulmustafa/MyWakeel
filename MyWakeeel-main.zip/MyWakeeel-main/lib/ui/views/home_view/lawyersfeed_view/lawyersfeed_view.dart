import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/shared/feed_card.dart';
import 'package:stacked/stacked.dart';

import 'lawyersfeed_viewmodel.dart';
import 'lawyersfeedcomments_view.dart';

class LawyersFeedView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LawyersFeedViewModel>.reactive(
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            iconTheme: IconThemeData(color: Colors.white),
            backgroundColor: appColor,
            title: Text(
              "Lawyer\'s Feeds",
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
          body:  Visibility(
            visible: model.feeds.length!=0,
            replacement: Container(),
            child:
             ListView.builder(
                  itemCount: model.feeds.length,
                  itemBuilder: (context, index) {
                    final feed = model.feeds[index];
                    return 
                     FeedCard(feed: feed, 
                    onLikeTapped:(){
                       model.likePost(feed);

                    },
                    onCommentTapped:(){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context)=>LawyerCommentView(feed)));
                    },
                    );
                  },
                ),
          ),
        );
      },
      onModelReady: (model){
        model.getPost();
      },
      viewModelBuilder: () => LawyersFeedViewModel(),
    );
  }
}
