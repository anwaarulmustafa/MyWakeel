import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:intl/intl.dart';
import 'package:mywakeel/models/feed_details.dart';
import 'package:mywakeel/ui/shared/const_size.dart';
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:stacked/stacked.dart';

import 'lawyersfeed_viewmodel.dart';

class LawyerCommentView extends StatelessWidget {
  final FeedDetails feedDetails;
  LawyerCommentView(this.feedDetails);
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LawyersFeedViewModel>.reactive(
      builder: (context, model, child){
        return Scaffold(
          appBar: AppBar(
            iconTheme: IconThemeData(color: Colors.white),
            backgroundColor: appColor,
            title: Text(
              "Feed",
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              children: [
                Container(
                    color: Colors.white,
                  child: ListView(
                    children: [
                      minHeight(context),
                       Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                child: feedDetails.posterImageUrl!=null?
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(16),
                                    shape: BoxShape.circle,
                                    
                                  ),
                                  child:FadeInImage(placeholder: AssetImage(appIcon),
                                   image: NetworkImage(feedDetails.posterImageUrl!))
                                ):CircleAvatar(
                                  radius: 16,backgroundImage:AssetImage(appIcon),
                                ),
                              ),
                              smallWidth(context),
                              Text(
                                feedDetails.posterName!,
                                style: TextStyle(
                                    fontSize: MySize.textSize(context, 6),
                                    fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                          Text(
                            DateFormat.jm().format(DateTime.parse(feedDetails.date!)),
                            style: TextStyle(fontSize: MySize.textSize(context, 4.5)),
                          ),
                        ],
                      ),
                      smallHeight(context),
                      Padding(
                        padding: const EdgeInsets.only(left: 45.0),
                        child: Text(
                          feedDetails.postText!,
                          style: TextStyle(fontSize: MySize.textSize(context, 4.5)),
                        ),
                      ),
                      Visibility(
                        visible:  feedDetails.containsImage!,
                        child: Container(
                              margin: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                              ),
                              clipBehavior: Clip.antiAlias,
                              child:  FadeInImage(
                                placeholder: AssetImage(appIcon), 
                                image: NetworkImage(feedDetails.postMedia!,),),)),
                       Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
               
                     Row(
              children: [
                  IconButton(
                    onPressed: model.likeinView,
                    iconSize: 30,
                    icon: Icon(model.isLiked?Icons.favorite:Icons.favorite_border, color: appColor),
                    ),
                    Text('${model.noOfLikes}', style: TextStyle(
                      fontSize: MySize.textSize(context, 4)
                    ),) ,
              ],
            ),
            smallWidth(context),
             Row(
              children: [
               Padding(
                   padding: const EdgeInsets.all(8.0),
                   child: Icon(FontAwesome5.comment_alt, color: appColor, size: 30),
               ),
                    Text('${model.nofComments}', style: TextStyle(
                      fontSize: MySize.textSize(context, 4)
                    ),) ,
              ],
            )
              
              
              
              ],
            ),
           
                      Divider(),
                      Visibility(
                        visible: model.comments.length !=0,
                        replacement: Container(
                          height: MySize.yMargin(context, 15),
                          child: Center(child: Text('Be the first to add a comment')),

                        ),
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: model.comments.length,
                        itemBuilder: (context, index){
                          final comment = model.comments[index];
                        return Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 15.0, top: 5, bottom: 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:[
                                  Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                   comment.posterImageUrl!=null?
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(16),
                                        shape: BoxShape.circle,
                                        
                                      ),
                                      child:FadeInImage(placeholder: AssetImage(appIcon),
                                       image: NetworkImage(comment.posterImageUrl!))
                                    ):CircleAvatar(
                                      radius: 16,backgroundImage:AssetImage(appIcon),
                                    ),
                                    smallWidth(context),
                                    Text(
                                     comment.posterName!,
                                      style: TextStyle(
                                          fontSize: MySize.textSize(context, 6),
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ],
                                ),
                                Text(
                                  DateFormat.jm().format(DateTime.parse(comment.date!)),
                                  style: TextStyle(fontSize: MySize.textSize(context, 4.5)),
                                ),
                              ],
                      ), 
                      minHeight(context),
                      Padding(
                              padding: const EdgeInsets.only(left: 45.0),
                              child: Text(
                                comment.postText!,
                                style: TextStyle(fontSize: MySize.textSize(context, 4.5)),
                              ),
                      ),
                                ]
                              ),
                            ),
                            
                      Divider(),
                          ],
                        );
                        },
                        ),
                      ),
                    ],
                  ),
                ),
               Align(
                  alignment: Alignment.bottomLeft,
                  child: Container(
                    padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
                    height: 60,
                    width: double.infinity,
                    color: Colors.grey[50],
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 15,
                        ),
                        Expanded(
                          child: TextField(
                            controller: controller,
                            decoration: InputDecoration(
                                hintText: "Write message...",
                                hintStyle: TextStyle(color: Colors.black54),
                                border: InputBorder.none),
                          ),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        FloatingActionButton(
                          onPressed: () {
                            model.createPostComment(controller.text);
                            controller.text = '';
                          },
                          child: Icon(
                            Icons.send,
                            color: Colors.white,
                            size: MySize.xMargin(context, 6),
                          ),
                          backgroundColor: appColor,
                          elevation: 0,
                        ),
                      ],
                    ),
                  ),
                ),
              
              ],
            ),
          ),
        );

      },
      onModelReady: (model){
          model.onCommentReady(feedDetails);

      },
       viewModelBuilder: ()=>LawyersFeedViewModel());
  }
}