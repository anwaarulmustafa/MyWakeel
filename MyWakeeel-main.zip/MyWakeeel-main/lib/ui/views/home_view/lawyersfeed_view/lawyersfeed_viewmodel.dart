import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/models/feed_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:stacked/stacked.dart';

class LawyersFeedViewModel extends BaseViewModel{
  FirebaseService  _firebaseService = locator<FirebaseService>();
  List<FeedDetails> feeds =[];
  
  bool isLiked = false;
  int noOfLikes =0, nofComments=0;
  
  List<FeedDetails> comments =[];
  FeedDetails? feed;
 
  onCommentReady(FeedDetails f){
    feed = f;
    nofComments= f.noOfComments!;
    noOfLikes = f.likedBy!.length;
     isLiked = f.likedBy!.contains(AppRepo.currentUserDetails!.uid);
    notifyListeners();

  }


  getPost() async {
   final f = await _firebaseService.getPosts() ;
   if(f.length !=0){
     feeds =f;
   }
    
    notifyListeners();
    
  }
  getPostComment() async {
    comments = await _firebaseService.getPostsComment(feed!.id) ;
    
  }
  createPostComment(text){
    comments.add( FeedDetails(
      posterId: AppRepo.currentUserDetails!.uid,
      posterName: AppRepo.currentUserDetails!.name,
      postText: text,
       date: DateTime.now().toString(),
       ));
  notifyListeners();

    _firebaseService.createPostComment( text, feed!.id);
  }

  likePost(f) async{
   await _firebaseService.likePostComment(f);

  }
  likeinView(){
        if(isLiked ==true){
        isLiked =false;
        noOfLikes -=1;
      }else{
        isLiked =true;
        noOfLikes +=1;
  notifyListeners();
      likePost(feed);
  notifyListeners();
      

    }

  }
 

  


}