import 'package:mywakeel/models/feed_details.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:stacked/stacked.dart';
import 'package:mywakeel/core/app.locator.dart';
import 'package:mywakeel/core/app.router.dart';
import 'package:stacked_services/stacked_services.dart';

class HomeViewModel extends BaseViewModel{
  NavigationService _navigationService = locator<NavigationService>();
  
  FirebaseService _firebaseService = locator<FirebaseService>();
  List<UserDetails> popularLawyers =[];
  List<UserDetails> aroundLawyers =[];
   List<FeedDetails> feeds =[];
  bool isLiked = false;
  int noOfLikes =0, nofComments=0;
  onReady() async {
    setBusy(true);
    notifyListeners();
    popularLawyers = await _firebaseService.getPopularLawyers();
    
    await  getPost();
    
    setBusy(false);
    
    notifyListeners();

  }
  onClientReady() async {
    setBusy(true);
    notifyListeners();
    popularLawyers = await _firebaseService.getPopularLawyers();
    aroundLawyers= await _firebaseService.getPopularLawyers();
    
    setBusy(false);
    
    notifyListeners();

  }
  getPost() async {
   final f = await _firebaseService.getPosts() ;
   if(f.length !=0){
     feeds =f;
   }
    
    notifyListeners();
    
  }
  // likePost(f) async{
  //  await _firebaseService.likePostComment(f);

  // }
  // likeinView(feed){
  //       if(isLiked ==true){
  //       isLiked =false;
  //       noOfLikes -=1;
  //     }else{
  //       isLiked =true;
  //       noOfLikes +=1;
  // notifyListeners();
  //     likePost(feed);
  // notifyListeners();
      

  //   }

  // }
   
  goBack()=> _navigationService.back();

  navigateToCaseHistory(){
    _navigationService.navigateTo(Routes.caseHistoryView);

  }
  navigateToCaseRequest(){
    _navigationService.navigateTo(Routes.caseRequestView);

  }
   navigateToLawyersfeed(){
    _navigationService.navigateTo(Routes.lawyersFeedView);

  }
  navigateToLawyersSearch(){
    _navigationService.navigateTo(Routes.searchView);

  }
   navigateToCreateNewPost() {
    _navigationService.navigateTo(Routes.createPostView);
  }
 
  
}