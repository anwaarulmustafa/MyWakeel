import 'dart:async';
import 'dart:developer';
import 'dart:core';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mywakeel/models/feed_details.dart';
import 'package:mywakeel/models/follow_details.dart';
import 'package:mywakeel/models/hire_details.dart';
import 'package:mywakeel/models/message_details.dart';
import 'package:mywakeel/models/messages_model.dart';
import 'package:mywakeel/models/notifications_details.dart';
import 'package:mywakeel/models/refer_details.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:firebase_storage/firebase_storage.dart' as storage;

class FirebaseService {
  final userCollection = FirebaseFirestore.instance.collection("Users");
  final messagecollection = FirebaseFirestore.instance.collection("Messages");
  final feedcollection = FirebaseFirestore.instance.collection("Feeds");
  final casescollection = FirebaseFirestore.instance.collection("Cases");
  final refercollection = FirebaseFirestore.instance.collection("Refer");
  final hirescollection = FirebaseFirestore.instance.collection("Hires");
  late storage.Reference storageReference;
  final now = DateTime.now();

  //SEARCHING

  Future<List<UserDetails>> searchLawyers() async {
    List<UserDetails> searchedUser = [];
    try {
      final doc = await userCollection
          .where(
            'userType',
            isEqualTo: 'Lawyer',
          )
          .get();
      final users =
          doc.docs.map((e) => UserDetails.fromJson(e.data())).toList();
      searchedUser = users;
    } catch (e) {
      log('$e');
    }

    return searchedUser;
  }

  Future<List<UserDetails>> getPopularLawyers() async {
    List<UserDetails> searchedUser = [];
    try {
      final doc = await userCollection
          .where(
            'userType',
            isEqualTo: 'Lawyer',
          )
          .get();
      log('$doc');
      final users =
          doc.docs.map((e) => UserDetails.fromJson(e.data())).toList();
      log('${users.toString()}');
      searchedUser = users;
    } catch (e) {
      log('$e');
    }

    return searchedUser;
  }

  //MESSAGING

  Future<MessageDetails> createChat(String id) async {
    UserDetails current = AppRepo.currentUserDetails!;
    final doc = messagecollection.doc();
    final message = MessageDetails(
      chatId: doc.id,
      senderId: current.uid,
      senderName: current.name,
      senderImageUrl: current.imageUrl,
      recieverId: id,
      isRead: false,
    );

    current.chats!.add(doc.id);
    await doc
        .set(
          message.createMap(),
        )
        .whenComplete(() async => await userCollection.doc(current.uid).update(
              {'chats': FieldValue.arrayUnion(current.chats!)},
            ).whenComplete(() async => await userCollection.doc(id).update(
                  {
                    'chats': FieldValue.arrayUnion([doc.id])
                  },
                )));

    return message;
  }

  Future<MessageDetails> sendMessage(
      String userId, String message, MessageDetails? messageDetails) async {
    String key;
    MessageDetails mes;

    if (messageDetails == null) {
      mes = await createChat(userId);
      key = mes.chatId!;
    } else {
      mes = messageDetails;
      key = messageDetails.chatId!;
    }
    final docs = messagecollection.doc(key);

    final chatDoc = docs.collection('Chats').doc();
    mes.recentmessage = message;
    mes.recentMessageTime = now.toString();
    await chatDoc
        .set(Message(
                senderId: AppRepo.firebaseCurrentUser!.uid,
                message: message,
                time: now.toString())
            .createMap())
        .whenComplete(() => docs.set(mes.updateMap(), SetOptions(merge: true)));

    return mes;
  }

  Future<List<MessageDetails>> getMessages() async {
    List<MessageDetails> messages = [];
    final chat = AppRepo.currentUserDetails!.chats;
    if (chat != null) {
      chat.forEach((element) async {
        final doc = await messagecollection.doc(element).get();
        MessageDetails mes = MessageDetails.fromSnap(doc.data()!);
        messages.add(mes);
      });

      await refreshUserDetails();
    }

    return messages;
  }

  Future<List<Message>> getSingleMessages(key) async {
    final doc = await messagecollection.doc(key).collection('Chats').get();
    return doc.docs.map((e) => Message.fromSnap(e.data())).toList();
  }

  Future<String> saveProfile(File cover, String title, String id) async {
    storageReference = storage.FirebaseStorage.instance
        .ref()
        .child('Lawyer Feeds')
        .child(id)
        .child('${Timestamp.now().microsecondsSinceEpoch}');
    final storage.UploadTask uploadTask = storageReference.putFile(cover);
    final storage.TaskSnapshot downloadUrl =
        (await uploadTask.whenComplete(() => null));
    final String url = (await downloadUrl.ref.getDownloadURL());
    return url;
  }

  Future<String> saveMedia(File cover, String id) async {
    storageReference = storage.FirebaseStorage.instance
        .ref()
        .child('Lawyer Feeds')
        .child(id)
        .child('${Timestamp.now().microsecondsSinceEpoch}');
    final storage.UploadTask uploadTask = storageReference.putFile(cover);
    final storage.TaskSnapshot downloadUrl =
        (await uploadTask.whenComplete(() => null));
    final String url = (await downloadUrl.ref.getDownloadURL());
    return url;
  }

  Future<FeedDetails> createPost({
    String? media,
    String? text,
    bool containsImage = false,
    bool containsVideo = false,
  }) async {
    final user = AppRepo.firebaseCurrentUser;
    final docs = feedcollection.doc();
    String? url, id = docs.id;
    if (containsImage) {
      url = await saveMedia(File(media!), id);
    }
    FeedDetails feed = FeedDetails(
      id: id,
      postMedia: url!,
      posterId: user!.uid,
      postText: text,
      posterImageUrl: user.photoURL,
      posterName: user.displayName,
      noOfComments: 0,
      noOfLikes: 0,
      likedBy: [],
      containsImage: containsImage,
      containsVideo: containsVideo,
      date: now.toString(),
    );

    await docs.set(feed.toJson()).whenComplete(() async {
      await userCollection.doc().update(
        {
          'feeds': FieldValue.arrayUnion([feed.id])
        },
      );
    });

    return feed;
  }

  Future<List<FeedDetails>> getPosts() async {
    final doc = await feedcollection.get();
    return doc.docs.map((e) => FeedDetails.fromJson(e.data())).toList();
  }

  Future<List<FeedDetails>> getUserPosts(List<String>? ids) async {
    List<FeedDetails> feeds = [];
    ids!.forEach((element) async {
      final e = await feedcollection.doc(element).get();
      feeds.add(FeedDetails.fromJson(e.data()!));
    });

    return feeds;
  }

  Stream<List<FeedDetails>> feeds() {
    return feedcollection.snapshots().map((json) =>
        json.docs.map((e) => FeedDetails.fromJson(e.data())).toList());
  }

  Future<FeedDetails> createPostComment(String? text, String? id) async {
    final user = AppRepo.firebaseCurrentUser;
    final docs = feedcollection.doc(id!);
    final comment = docs.collection('Comments').doc();
    FeedDetails feed = FeedDetails(
      id: id,
      posterId: user!.uid,
      postText: text,
      date: now.toString(),
    );
    await comment.set(feed.toJson()).whenComplete(() async =>
        await docs.update({'noOfComments': FieldValue.increment(1)}));

    return feed;
  }

  Future<FeedDetails> likePostComment(FeedDetails feed) async {
    final docs = feedcollection.doc(feed.id);

    final like = feed.likedBy;
    final id = AppRepo.currentUserDetails!.uid;

    if (like!.contains(id)) {
      like.remove(id);
      log('h');
    } else {
      like.add(id!);
      log('he');
    }
    await docs.update({'likedBy': like});
    return feed;
  }

  Future<List<FeedDetails>> getPostsComment(id) async {
    final doc = await feedcollection.doc(id).collection('Comments').get();
    return doc.docs.map((e) => FeedDetails.fromJson(e.data())).toList();
  }

  Future<void> referUser(userName, userId, toName, toId) async {
    log('here');
    try {
      final doc = refercollection.doc();
      String key = doc.id;
      ReferDetails refer = ReferDetails(
        id: key,
        refferedUser: userName,
        refferedUserId: userId,
        refferedBy: AppRepo.currentUserDetails!.name,
        refferedById: AppRepo.currentUserDetails!.uid,
        refferedTo: toName,
        refferedToId: toId,
        isAccepted: false,
        isReacted: false,
        dateReffered: now.toString(),
      );
      final notif = NotificationsDetails(
        date: now.toString(),
        isRead: false,
        notificationId: key,
      );

      log('here1');
      await refercollection.doc(key).set(refer.toJson());
      log('here2');
      await userCollection.doc(AppRepo.currentUserDetails!.uid).update(
        {
          'reffered': FieldValue.arrayUnion([
            key,
          ])
        },
      );

      notif.notificationType = 'Refer';
      log('here3');
      await userCollection.doc(refer.refferedToId).update(
        {
          'reffered': FieldValue.arrayUnion([
            key,
          ]),
          'notifications': FieldValue.arrayUnion([
            notif.toJson(),
          ]),
        },
      );
      log('here 4');
      notif.notificationType = 'Referred';
      log('here');
      await userCollection.doc(refer.refferedUserId).update(
        {
          'refferees': FieldValue.arrayUnion([
            key,
          ]),
          'notifications': FieldValue.arrayUnion([
            notif.toJson(),
          ]),
        },
      );

      await refreshUserDetails();
    } catch (e) {
      log('$e');
    }
  }

  Future<void> updateReferUser(bool isAccepted, ReferDetails refer) async {
    refer.isAccepted = isAccepted;
    refer.isReacted = true;
    refer.dateAccepted = now.toString();
    final notif = NotificationsDetails(
      date: now.toString(),
      isRead: false,
      notificationId: refer.id,
      notificationType: isAccepted ? 'Refer Accepted' : 'Refer Rejected',
    );

    await refercollection
        .doc(refer.id)
        .set(refer.toJson(), SetOptions(merge: true));
    await FirebaseFirestore.instance
        .collection("Users")
        .doc(refer.refferedById)
        .set(
            {
          'notifications': FieldValue.arrayUnion([notif.toJson()])
        },
            SetOptions(
              merge: true,
            ));

    await refreshUserDetails();
  }

  Future<void> updateNotification(NotificationsDetails notif) async {
    notif.isRead = true;
    await FirebaseFirestore.instance
        .collection("Users")
        .doc(AppRepo.currentUserDetails!.uid)
        .set({
      'notifications': FieldValue.arrayUnion([notif.toJson()])
    }, SetOptions(merge: true));

    await refreshUserDetails();
  }

  Future<List<ReferDetails>> getReffered() async {
    final doc = await refercollection.get();
    return doc.docs.map((e) => ReferDetails.fromJson(e.data())).toList();
  }

  Future<void> hireUser(userName, userId, summary, title) async {
    try {
      final doc = refercollection.doc();
      String key = doc.id;
      HireDetails hire = HireDetails(
        id: key,
        hiredUser: userName,
        hiredUserId: userId,
        jobTitle: title,
        summary: summary,
        hiredBy: AppRepo.currentUserDetails!.name,
        hiredById: AppRepo.currentUserDetails!.uid,
        dateHired: now.toString(),
        isAccepted: false,
        isReacted: false,
        inProgress: false,
        inCompleted: false,
      );
      final notif = NotificationsDetails(
        date: now.toString(),
        isRead: false,
        notificationId: key,
      );

      log('here v');
      await hirescollection.doc(key).set(hire.toJson());
      await userCollection.doc(AppRepo.currentUserDetails!.uid).update(
        {
          'hires': FieldValue.arrayUnion([
            key,
          ])
        },
      );

      notif.notificationType = 'Hired';
      await userCollection.doc(hire.hiredUserId).update(
        {
          'hires': FieldValue.arrayUnion([
            key,
          ]),
          'notifications': FieldValue.arrayUnion([notif.toJson()]),
        },
      );
      await refreshUserDetails();

      log('here done');
    } catch (e) {
      log('here done $e');
    }
  }

  Future<void> updateHireUser(bool isAccepted, HireDetails hire) async {
    hire.isAccepted = isAccepted;
    hire.isReacted = true;
    hire.inProgress = true;
    final notif = NotificationsDetails(
      date: now.toString(),
      isRead: false,
      notificationId: hire.id,
      notificationType: isAccepted ? 'Hire Accepted' : 'Hire Rejected',
    );

    await hirescollection
        .doc(hire.id)
        .set(hire.toJson(), SetOptions(merge: true));
    await userCollection.doc(hire.hiredById).update({
      'notifications': FieldValue.arrayUnion([notif.toJson()]),
    });
    await refreshUserDetails();
  }

  Future<void> updateHireUserCompleted(HireDetails hire) async {
    hire.inProgress = false;
    hire.inCompleted = true;
    final notif = NotificationsDetails(
      date: now.toString(),
      isRead: false,
      notificationId: hire.id,
      notificationType: 'Hire Completed',
    );

    await hirescollection.doc(hire.id).update(hire.toJson());
    await userCollection.doc(hire.hiredById).update({
      'notifications': FieldValue.arrayUnion([notif.toJson()]),
    });
    await refreshUserDetails();
  }

  Future<List<HireDetails>> getHires() async {
    final doc = await hirescollection.get();
    return doc.docs.map((e) => HireDetails.fromJson(e.data())).toList();
  }

  Future<void> refreshUserDetails() async {
    try {
      final user = await FirebaseFirestore.instance
          .collection("Users")
          .doc(AppRepo.currentUserDetails!.uid)
          .get();
      AppRepo.currentUserDetails = UserDetails.fromJson(user.data()!);
    } catch (e) {
      log('message $e');
    }
  }

  Future<bool> followUser(UserDetails userDetails) async {
    bool isFollowing = false;
    try {
      UserDetails userToFollow = userDetails;
      await refreshUserDetails();
      final user = FirebaseFirestore.instance.collection("Users");
      final followed = user.doc(userToFollow.uid);

      final followedBy = user.doc(AppRepo.currentUserDetails!.uid);
      final currentUser = AppRepo.currentUserDetails!;

      userToFollow = await followed
          .get()
          .then((value) => UserDetails.fromJson(value.data()!));
      FollowDetails follow = FollowDetails(
        name: userToFollow.name,
        uid: userToFollow.uid,
        imageUrl: userToFollow.imageUrl,
      );
      final notif = NotificationsDetails(
        date: now.toString(),
        isRead: false,
        notificationId: userDetails.uid,
        notificationType: 'Follow',
      );

      UserDetails details = UserDetails(
        feeds: currentUser.feeds,
        follows: currentUser.follows,
        followers: currentUser.followers,
        uid: currentUser.uid,
        userType: currentUser.userType,
        lat: currentUser.lat,
        long: currentUser.long,
        gender: currentUser.gender,
        hired: currentUser.hired,
        hires: currentUser.hires,
        referals: currentUser.referals,
        reffered: currentUser.reffered,
        refferees: currentUser.refferees,
        chats: currentUser.chats,
        notifications: currentUser.notifications,
        name: currentUser.name,
        email: currentUser.email,
        imageUrl: currentUser.imageUrl,
        experience: currentUser.experience,
        cetifications: currentUser.cetifications,
        court: currentUser.court,
        city: currentUser.city,
      );
      final f = details.follows!.where((e) => e.uid == follow.uid);
      if (f.isEmpty) {
        userToFollow.followers!.add(follow);
        details.follows!.add(follow);
        userToFollow.notifications!.add(notif);
        await followedBy.set(details.toJson());
        await followed.set(userToFollow.toJson());
        isFollowing = true;

        log('he');
      } else {
        userToFollow.followers!
            .removeWhere((element) => element.uid == follow.uid);
        details.follows!.removeWhere((element) => element.uid == follow.uid);
        await followedBy.set(details.toJson());
        await followed.set(userToFollow.toJson());
        isFollowing = false;
        log('h');
      }
    } catch (e) {
      log('he $e');
    }

    return isFollowing;
  }

  Future<UserDetails> getFollowUser(id) async {
    UserDetails userDetails = UserDetails();
    try {
      log('here');
      final result =
          await FirebaseFirestore.instance.collection("Users").doc(id).get();
      userDetails = UserDetails.fromJson(result.data()!);
    } catch (e) {
      log('message $e');
    }
    return userDetails;
  }
}
