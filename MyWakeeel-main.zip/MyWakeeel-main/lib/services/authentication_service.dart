import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mywakeel/models/certification_details.dart';
import 'package:mywakeel/models/experience_details.dart';
import 'package:mywakeel/models/user_details.dart';
import 'package:mywakeel/ui/shared/app_repo.dart';
import 'package:firebase_storage/firebase_storage.dart' as storage;
import 'package:mywakeel/ui/shared/const_widget.dart';
import 'package:mywakeel/ui/shared/location.dart';

class AuthenticationService {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  late storage.Reference storageReference;

  Future<String> signUpWithEmail({
    required String email,
    required String password,
    required String name,
    required String gender,
    required String city,
    required String userType,
    String? court,
    required BuildContext context,
    required GlobalKey scaffoldKey,
  }) async {
    var status = 'none';
    log('first');

    try {
      final pos = await determinePosition();
      log('$pos');
      showLoadingDialogWithText(context, scaffoldKey, 'Signing Up');
      User? user = (await _firebaseAuth.createUserWithEmailAndPassword(
              email: email, password: password))
          .user;

      log('firstt $user');

      if (user != null) {
        await user.updateProfile(displayName: name);
        await user.reload();
        UserDetails userDetails = UserDetails(
            name: name.trim(),
            city: city.trim(),
            lat: pos.latitude.toString(),
            long: pos.longitude.toString(),
            userType: userType,
            uid: user.uid,
            email: user.email,
            gender: gender,
            chats: [],
            experience: [],
            cetifications: [],
            follows: [],
            feeds: [],
            followers: [],
            referals: [],
            reffered: [],
            refferees: [],
            notifications: [],
            court: court!.trim());
        await FirebaseFirestore.instance
            .collection("Users")
            .doc(userDetails.uid)
            .set(userDetails.toJson());
        await user.sendEmailVerification();
        Navigator.of(scaffoldKey.currentContext!).pop();
        showMessage(context, 'Sign up sucessful, please verify your email.');
        status = 'true';
      }
    } on FirebaseAuthException catch (e) {
      print('auth exception $e');
      status = '$e';
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '${e.message}');
      log('status $status');
    } on PlatformException catch (e) {
      print('plat exception $e');
      status = '$e';
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '${e.message}');
      log('status $status');
    } catch (e) {
      print('none exception $e');
      status = '$e';
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '$e');
    }

    return status;
  }

  Future<bool> logInWithEmail({
    required String email,
    required String password,
    context,
    required GlobalKey scaffoldKey,
  }) async {
    bool status = false;

    try {
      showLoadingDialogWithText(context, scaffoldKey, 'Signing In');
      var authResult = await _firebaseAuth.signInWithEmailAndPassword(
          email: email, password: password);
      bool verified = authResult.user!.emailVerified;
      if (verified) {
        status = true;
        await getUserDetails(
          authResult.user!.uid,
        );
        Navigator.of(scaffoldKey.currentContext!).pop();
        showMessage(context, 'Sign in sucessful,');
      } else {
        status = false;
        Navigator.of(scaffoldKey.currentContext!).pop();
        showMessage(context, 'Email not verified, Please verify your email,');
      }
    } on FirebaseAuthException catch (e) {
      print('auth exception ${e.message}');
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '${e.message}');
      status = false;
    } on PlatformException catch (e) {
      print('plat exception $e');
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '${e.message}');
      status = false;
    } catch (e) {
      print('none exception $e');
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '$e');
      status = false;
    }

    return status;
  }

  Future<void> getUserDetails(String id) async {
    try {
      log('here');
      final user =
          await FirebaseFirestore.instance.collection("Users").doc(id).get();
      AppRepo.currentUserDetails = UserDetails.fromJson(user.data()!);
      AppRepo.firebaseCurrentUser = _firebaseAuth.currentUser;
      final pos = await determinePosition();
      if (pos.latitude != double.parse(AppRepo.currentUserDetails!.lat!) &&
          pos.longitude != double.parse(AppRepo.currentUserDetails!.long!)) {
        await FirebaseFirestore.instance.collection("Users").doc(id).update({
          'lat': pos.latitude.toString(),
          'long': pos.longitude.toString(),
        });
        final user =
            await FirebaseFirestore.instance.collection("Users").doc(id).get();
        AppRepo.currentUserDetails = UserDetails.fromJson(user.data()!);
        AppRepo.isLawyer =
            AppRepo.currentUserDetails!.userType == 'Lawyer' ? true : false;
      }

      print(AppRepo.currentUserDetails);
      print(AppRepo.firebaseCurrentUser);
    } catch (e) {
      log('message $e');
    }
  }

  Future<String> saveProfileImage(File cover, String id) async {
    storageReference = storage.FirebaseStorage.instance
        .ref()
        .child('User\'s')
        .child(id)
        .child('${Timestamp.now().microsecondsSinceEpoch}');

    final storage.UploadTask uploadTask = storageReference.putFile(cover);
    final storage.TaskSnapshot downloadUrl =
        (await uploadTask.whenComplete(() => null));
    final String url = (await downloadUrl.ref.getDownloadURL());
    return url;
  }

  Future<void> updateUserDetail({
    String? name,
    String? url,
    String? court,
    String? city,
    List<ExperienceDetails>? experience,
    List<CertificationsDetails>? cetifications,
    context,
    scaffoldKey,
  }) async {
    try {
      showLoadingDialogWithText(context, scaffoldKey, 'Updating');
      String? profile = AppRepo.currentUserDetails!.imageUrl;
      if (url != null) {
        profile =
            await saveProfileImage(File(url), AppRepo.currentUserDetails!.uid!);
      }
      final currentUser = AppRepo.currentUserDetails!;
      UserDetails details = UserDetails(
        feeds: currentUser.feeds,
        follows: currentUser.follows,
        followers: currentUser.followers,
        uid: currentUser.uid,
        userType: currentUser.userType,
        lat: currentUser.lat,
        long: currentUser.long,
        gender: currentUser.gender,
        hired: currentUser.hired,
        hires: currentUser.hires,
        referals: currentUser.referals,
        reffered: currentUser.reffered,
        refferees: currentUser.refferees,
        chats: currentUser.chats,
        notifications: currentUser.notifications,
        name: name ?? currentUser.name,
        imageUrl: profile,
        email: currentUser.email,
        experience: experience ?? currentUser.experience,
        cetifications: cetifications ?? currentUser.cetifications,
        court: court ?? currentUser.court,
        city: city ?? currentUser.city,
      );
      final ref = FirebaseFirestore.instance
          .collection("Users")
          .doc(AppRepo.currentUserDetails!.uid);
      await ref.update(details.toJson());
      final user = await ref.get();
      AppRepo.currentUserDetails = UserDetails.fromJson(user.data()!);
      log('${AppRepo.currentUserDetails}');
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, 'Profile update Succeful');
    } catch (e) {
      log('error update profile $e');
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '$e');
    }
  }

  Future<bool> isUserLoggedIn() async {
    bool isLoggedIn = false;

    User? user = _firebaseAuth.currentUser;
    user?.reload();

    try {
      if (user != null) {
        isLoggedIn = true;
        await getUserDetails(user.uid);
      } else {
        isLoggedIn = false;
        log('uuuu');
      }
      log('$isLoggedIn uuu');
    } catch (e) {
      log('message log $e');
    }

    return isLoggedIn;
  }

  Future<void> signOut() async => await _firebaseAuth.signOut();

  Future sendChangePasswordEmail({email, context, scaffoldKey}) async {
    try {
      showLoadingDialogWithText(context, scaffoldKey, 'Sending Reset email');

      await _firebaseAuth.sendPasswordResetEmail(email: email!);
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, 'Reset email sent');
    } catch (e) {
      Navigator.of(scaffoldKey.currentContext!).pop();
      showMessage(context, '$e');
    }
  }

  Future<void> deleteUser() async {
    try {
      User? user = _firebaseAuth.currentUser!;
      user.reload();

      await FirebaseFirestore.instance
          .collection("Users")
          .doc(user.uid)
          .delete()
          .whenComplete(() async => await user.delete());
    } catch (e) {
      log('$e');
    }
  }

  showMessage(context, message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$message'),
    ));
  }
}
