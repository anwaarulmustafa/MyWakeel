import 'package:mywakeel/services/authentication_service.dart';
import 'package:mywakeel/services/firebase_service.dart';
import 'package:mywakeel/ui/views/authentication/authentication_view.dart';
import 'package:mywakeel/ui/views/authentication/clientsignup/clientsignup_view.dart';
import 'package:mywakeel/ui/views/authentication/forgotpassword/forgot_view.dart';
import 'package:mywakeel/ui/views/authentication/lawsignup/lawsignup_view.dart';
import 'package:mywakeel/ui/views/authentication/mainsignup_view/mainsignup_view.dart';
import 'package:mywakeel/ui/views/authentication/signin_view/signin_view.dart';
import 'package:mywakeel/ui/views/home_view/case_history/case_history_view.dart';
import 'package:mywakeel/ui/views/home_view/case_request/case_request_view.dart';
import 'package:mywakeel/ui/views/home_view/home_view.dart';
import 'package:mywakeel/ui/views/home_view/lawyersfeed_view/lawyersfeed_view.dart';
import 'package:mywakeel/ui/views/main_view/main_view.dart';
import 'package:mywakeel/ui/views/messages/message_view/message_view.dart';
import 'package:mywakeel/ui/views/notifications_view/notifications_view.dart';
import 'package:mywakeel/ui/views/profile/createpost_view/createpost_view.dart';
import 'package:mywakeel/ui/views/profile/edit_profile/editprofile_view.dart';
import 'package:mywakeel/ui/views/profile/profile_view/profile_view.dart';
import 'package:mywakeel/ui/views/profile/settings_view/settings_view.dart';
import 'package:mywakeel/ui/views/search/map_view/map_view.dart';
import 'package:mywakeel/ui/views/search/search_view/search_view.dart';
import 'package:mywakeel/ui/views/startup/startup_view.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:stacked_services/stacked_services.dart';

@StackedApp(
  routes: [
    MaterialRoute(page: StartUpView, initial: true),
    CupertinoRoute(page: SignInView),
    CupertinoRoute(page: MainSignUpView),
    CupertinoRoute(page: LawyerSignUpView),
    CupertinoRoute(page: ClientSignUpView),
    CupertinoRoute(page: ForgotView),   
    CupertinoRoute(page: HomeView),
    CupertinoRoute(page: MainView),
    CupertinoRoute(page: MessageView),
    CupertinoRoute(page: AuthenticationUpView),
    // CupertinoRoute(page: PersonalMessageView),
    CupertinoRoute(page: ProfileView),
    CupertinoRoute(page: NotificationsView),
    CupertinoRoute(page: SearchView),
    CupertinoRoute(page: CaseHistoryView),
    CupertinoRoute(page: CaseRequestView),
    CupertinoRoute(page: LawyersFeedView),  
    CupertinoRoute(page: EditProfileView),   
    CupertinoRoute(page: CreatePostView),    
    CupertinoRoute(page: SettingsView),     
    CupertinoRoute(page: MapView),  
    // CupertinoRoute(page: EditProfileView),
  ],
  dependencies: [
    LazySingleton(classType: NavigationService),
    LazySingleton(classType: FirebaseService),
    LazySingleton(classType: AuthenticationService),
  ]
  )
class AppSetup{

}