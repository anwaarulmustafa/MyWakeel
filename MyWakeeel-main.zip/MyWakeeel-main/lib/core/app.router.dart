// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedRouterGenerator
// **************************************************************************

// ignore_for_file: public_member_api_docs

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../ui/views/authentication/authentication_view.dart';
import '../ui/views/authentication/clientsignup/clientsignup_view.dart';
import '../ui/views/authentication/forgotpassword/forgot_view.dart';
import '../ui/views/authentication/lawsignup/lawsignup_view.dart';
import '../ui/views/authentication/mainsignup_view/mainsignup_view.dart';
import '../ui/views/authentication/signin_view/signin_view.dart';
import '../ui/views/home_view/case_history/case_history_view.dart';
import '../ui/views/home_view/case_request/case_request_view.dart';
import '../ui/views/home_view/home_view.dart';
import '../ui/views/home_view/lawyersfeed_view/lawyersfeed_view.dart';
import '../ui/views/main_view/main_view.dart';
import '../ui/views/messages/message_view/message_view.dart';
import '../ui/views/notifications_view/notifications_view.dart';
import '../ui/views/profile/createpost_view/createpost_view.dart';
import '../ui/views/profile/edit_profile/editprofile_view.dart';
import '../ui/views/profile/profile_view/profile_view.dart';
import '../ui/views/profile/settings_view/settings_view.dart';
import '../ui/views/search/map_view/map_view.dart';
import '../ui/views/search/search_view/search_view.dart';
import '../ui/views/startup/startup_view.dart';

class Routes {
  static const String startUpView = '/';
  static const String signInView = '/sign-in-view';
  static const String mainSignUpView = '/main-sign-up-view';
  static const String lawyerSignUpView = '/lawyer-sign-up-view';
  static const String clientSignUpView = '/client-sign-up-view';
  static const String forgotView = '/forgot-view';
  static const String homeView = '/home-view';
  static const String mainView = '/main-view';
  static const String messageView = '/message-view';
  static const String authenticationUpView = '/authentication-up-view';
  static const String profileView = '/profile-view';
  static const String notificationsView = '/notifications-view';
  static const String searchView = '/search-view';
  static const String caseHistoryView = '/case-history-view';
  static const String caseRequestView = '/case-request-view';
  static const String lawyersFeedView = '/lawyers-feed-view';
  static const String editProfileView = '/edit-profile-view';
  static const String createPostView = '/create-post-view';
  static const String settingsView = '/settings-view';
  static const String mapView = '/map-view';
  static const all = <String>{
    startUpView,
    signInView,
    mainSignUpView,
    lawyerSignUpView,
    clientSignUpView,
    forgotView,
    homeView,
    mainView,
    messageView,
    authenticationUpView,
    profileView,
    notificationsView,
    searchView,
    caseHistoryView,
    caseRequestView,
    lawyersFeedView,
    editProfileView,
    createPostView,
    settingsView,
    mapView,
  };
}

class StackedRouter extends RouterBase {
  @override
  List<RouteDef> get routes => _routes;
  final _routes = <RouteDef>[
    RouteDef(Routes.startUpView, page: StartUpView),
    RouteDef(Routes.signInView, page: SignInView),
    RouteDef(Routes.mainSignUpView, page: MainSignUpView),
    RouteDef(Routes.lawyerSignUpView, page: LawyerSignUpView),
    RouteDef(Routes.clientSignUpView, page: ClientSignUpView),
    RouteDef(Routes.forgotView, page: ForgotView),
    RouteDef(Routes.homeView, page: HomeView),
    RouteDef(Routes.mainView, page: MainView),
    RouteDef(Routes.messageView, page: MessageView),
    RouteDef(Routes.authenticationUpView, page: AuthenticationUpView),
    RouteDef(Routes.profileView, page: ProfileView),
    RouteDef(Routes.notificationsView, page: NotificationsView),
    RouteDef(Routes.searchView, page: SearchView),
    RouteDef(Routes.caseHistoryView, page: CaseHistoryView),
    RouteDef(Routes.caseRequestView, page: CaseRequestView),
    RouteDef(Routes.lawyersFeedView, page: LawyersFeedView),
    RouteDef(Routes.editProfileView, page: EditProfileView),
    RouteDef(Routes.createPostView, page: CreatePostView),
    RouteDef(Routes.settingsView, page: SettingsView),
    RouteDef(Routes.mapView, page: MapView),
  ];
  @override
  Map<Type, StackedRouteFactory> get pagesMap => _pagesMap;
  final _pagesMap = <Type, StackedRouteFactory>{
    StartUpView: (data) {
      return MaterialPageRoute<dynamic>(
        builder: (context) => const StartUpView(),
        settings: data,
      );
    },
    SignInView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => SignInView(),
        settings: data,
      );
    },
    MainSignUpView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => MainSignUpView(),
        settings: data,
      );
    },
    LawyerSignUpView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => LawyerSignUpView(),
        settings: data,
      );
    },
    ClientSignUpView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => ClientSignUpView(),
        settings: data,
      );
    },
    ForgotView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => ForgotView(),
        settings: data,
      );
    },
    HomeView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => HomeView(),
        settings: data,
      );
    },
    MainView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => MainView(),
        settings: data,
      );
    },
    MessageView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => MessageView(),
        settings: data,
      );
    },
    AuthenticationUpView: (data) {
      var args = data.getArgs<AuthenticationUpViewArguments>(
        orElse: () => AuthenticationUpViewArguments(),
      );
      return CupertinoPageRoute<dynamic>(
        builder: (context) => AuthenticationUpView(key: args.key),
        settings: data,
      );
    },
    ProfileView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => ProfileView(),
        settings: data,
      );
    },
    NotificationsView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => NotificationsView(),
        settings: data,
      );
    },
    SearchView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => SearchView(),
        settings: data,
      );
    },
    CaseHistoryView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => CaseHistoryView(),
        settings: data,
      );
    },
    CaseRequestView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => CaseRequestView(),
        settings: data,
      );
    },
    LawyersFeedView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => LawyersFeedView(),
        settings: data,
      );
    },
    EditProfileView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => EditProfileView(),
        settings: data,
      );
    },
    CreatePostView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => CreatePostView(),
        settings: data,
      );
    },
    SettingsView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => SettingsView(),
        settings: data,
      );
    },
    MapView: (data) {
      return CupertinoPageRoute<dynamic>(
        builder: (context) => MapView(),
        settings: data,
      );
    },
  };
}

/// ************************************************************************
/// Arguments holder classes
/// *************************************************************************

/// AuthenticationUpView arguments holder class
class AuthenticationUpViewArguments {
  final Key? key;
  AuthenticationUpViewArguments({this.key});
}
