// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'experience_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ExperienceDetails _$ExperienceDetailsFromJson(Map json) {
  return ExperienceDetails(
    clients: json['clients'] as String?,
    date: json['date'] as String?,
    jobTitle: json['jobTitle'] as String?,
    summary: json['summary'] as String?,
  );
}

Map<String, dynamic> _$ExperienceDetailsToJson(ExperienceDetails instance) =>
    <String, dynamic>{
      'jobTitle': instance.jobTitle,
      'clients': instance.clients,
      'date': instance.date,
      'summary': instance.summary,
    };
