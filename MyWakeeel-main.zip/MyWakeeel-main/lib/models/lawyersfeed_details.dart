class LawyersFeedDetails{
  String? posterId, posterImage, posterName;
  String? postContent;
  String? datePosted;
  int? noOfLikes, noOfComments;
  LawyersFeedDetails({this.posterImage,this.posterId, this.posterName,
   this.datePosted,this.noOfComments, this.noOfLikes, this.postContent});

   

}