// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'follow_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FollowDetails _$FollowDetailsFromJson(Map json) {
  return FollowDetails(
    name: json['name'] as String?,
    uid: json['uid'] as String?,
    imageUrl: json['imageUrl'] as String?,
  );
}

Map<String, dynamic> _$FollowDetailsToJson(FollowDetails instance) =>
    <String, dynamic>{
      'name': instance.name,
      'uid': instance.uid,
      'imageUrl': instance.imageUrl,
    };
