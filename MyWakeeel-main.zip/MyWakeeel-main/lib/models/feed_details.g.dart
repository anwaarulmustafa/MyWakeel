// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedDetails _$FeedDetailsFromJson(Map json) {
  return FeedDetails(
    id: json['id'] as String?,
    postMedia: json['postMedia'] as String?,
    postText: json['postText'] as String?,
    likedBy:
        (json['likedBy'] as List<dynamic>?)?.map((e) => e as String).toList(),
    posterId: json['posterId'] as String?,
    posterImageUrl: json['posterImageUrl'] as String?,
    posterName: json['posterName'] as String?,
    noOfLikes: json['noOfLikes'] as int?,
    noOfComments: json['noOfComments'] as int?,
    containsImage: json['containsImage'] as bool?,
    containsVideo: json['containsVideo'] as bool?,
    date: json['date'],
  );
}

Map<String, dynamic> _$FeedDetailsToJson(FeedDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'posterName': instance.posterName,
      'posterId': instance.posterId,
      'posterImageUrl': instance.posterImageUrl,
      'postText': instance.postText,
      'postMedia': instance.postMedia,
      'date': instance.date,
      'containsVideo': instance.containsVideo,
      'containsImage': instance.containsImage,
      'noOfLikes': instance.noOfLikes,
      'noOfComments': instance.noOfComments,
      'likedBy': instance.likedBy,
    };
