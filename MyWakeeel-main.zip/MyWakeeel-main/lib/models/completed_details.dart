import 'package:json_annotation/json_annotation.dart';
part 'completed_details.g.dart';

@JsonSerializable(anyMap: true,)
class CompletedJobsDetails {
  String? jobTitle, clients, date, summary, status, rating;
  CompletedJobsDetails({this.clients, this.date, this.jobTitle,
   this.summary, this.status, this.rating});
   
  factory
  CompletedJobsDetails.fromJson(Map<String, dynamic> json)=>_$CompletedJobsDetailsFromJson(json);
  
  Map<String, dynamic> toJson()=>_$CompletedJobsDetailsToJson(this);

  
  //  Map<String, dynamic> createMap() {
  //   return {
  //     'jobTitle': jobTitle,
  //     'clients': clients,
  //     'date': date,
  //     'summary': summary,
  //     'status': status,
  //     'rating': rating,
  //   };
  // }

  // CompletedJobsDetails.fromSnap(Map fireStore)
  //     :
  //       jobTitle = fireStore['jobTitle'],
  //       clients = fireStore['clients'],
  //       date = fireStore['date'],
  //       status = fireStore['status'],
  //       rating = fireStore['rating'],
  //       summary= fireStore['summary'];

  // @override
  //   String toString() {
  //     return 'jobTitle: $jobTitle';
  //   }
}