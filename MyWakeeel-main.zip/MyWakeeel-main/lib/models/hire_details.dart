import 'package:json_annotation/json_annotation.dart';

part 'hire_details.g.dart';
@JsonSerializable(anyMap: true,)
class HireDetails{
  String? id, hiredUser, hiredUserId,hiredBy, hiredById;
  String? jobTitle, summary, rating;
  var dateHired, dateUpdated;
  bool? isAccepted, isReacted, inProgress, inCompleted;
  HireDetails({this.id, this.hiredUser, this.hiredUserId, 
  this.hiredBy, this.hiredById, this.isAccepted,this.isReacted, this.jobTitle,
  this.summary, this.rating,
   this.dateHired, this.dateUpdated, this.inProgress,this.inCompleted });

  

  factory
  HireDetails.fromJson(Map<String, dynamic> json)=>_$HireDetailsFromJson(json);

  Map<String, dynamic> toJson()=>_$HireDetailsToJson(this);

  
}