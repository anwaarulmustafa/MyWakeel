// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserDetails _$UserDetailsFromJson(Map json) {
  return UserDetails(
    name: json['name'] as String?,
    imageUrl: json['imageUrl'] as String?,
    uid: json['uid'] as String?,
    email: json['email'] as String?,
    userType: json['userType'] as String?,
    experience: (json['experience'] as List<dynamic>?)
        ?.map((e) =>
            ExperienceDetails.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
    lat: json['lat'] as String?,
    long: json['long'] as String?,
    cetifications: (json['cetifications'] as List<dynamic>?)
        ?.map((e) =>
            CertificationsDetails.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
    gender: json['gender'] as String?,
    hires: (json['hires'] as List<dynamic>?)?.map((e) => e as String).toList(),
    hired: (json['hired'] as List<dynamic>?)?.map((e) => e as String).toList(),
    city: json['city'] as String?,
    court: json['court'] as String?,
    chats: (json['chats'] as List<dynamic>?)?.map((e) => e as String).toList(),
    referals:
        (json['referals'] as List<dynamic>?)?.map((e) => e as String).toList(),
    feeds: (json['feeds'] as List<dynamic>?)?.map((e) => e as String).toList(),
    followers: (json['followers'] as List<dynamic>?)
        ?.map(
            (e) => FollowDetails.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
    follows: (json['follows'] as List<dynamic>?)
        ?.map(
            (e) => FollowDetails.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
    reffered:
        (json['reffered'] as List<dynamic>?)?.map((e) => e as String).toList(),
    refferees:
        (json['refferees'] as List<dynamic>?)?.map((e) => e as String).toList(),
    notifications: (json['notifications'] as List<dynamic>?)
        ?.map((e) =>
            NotificationsDetails.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
  );
}

Map<String, dynamic> _$UserDetailsToJson(UserDetails instance) =>
    <String, dynamic>{
      'name': instance.name,
      'imageUrl': instance.imageUrl,
      'uid': instance.uid,
      'email': instance.email,
      'lat': instance.lat,
      'long': instance.long,
      'userType': instance.userType,
      'gender': instance.gender,
      'court': instance.court,
      'city': instance.city,
      'chats': instance.chats,
      'hires': instance.hires,
      'hired': instance.hired,
      'reffered': instance.reffered,
      'referals': instance.referals,
      'refferees': instance.refferees,
      'feeds': instance.feeds,
      'experience': instance.experience?.map((e) => e.toJson()).toList(),
      'cetifications': instance.cetifications?.map((e) => e.toJson()).toList(),
      'follows': instance.follows?.map((e) => e.toJson()).toList(),
      'followers': instance.followers?.map((e) => e.toJson()).toList(),
      'notifications': instance.notifications?.map((e) => e.toJson()).toList(),
    };
