import 'package:json_annotation/json_annotation.dart';
part 'certification_details.g.dart';


@JsonSerializable(anyMap: true,)
class CertificationsDetails {
  String? title, date;
  CertificationsDetails({ this.date, this.title});
  factory
  CertificationsDetails.fromJson(Map<String, dynamic> json)=>_$CertificationsDetailsFromJson(json);
  
  Map<String, dynamic> toJson()=>_$CertificationsDetailsToJson(this);


}