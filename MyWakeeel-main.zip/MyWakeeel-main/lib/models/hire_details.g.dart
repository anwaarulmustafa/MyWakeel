// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'hire_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HireDetails _$HireDetailsFromJson(Map json) {
  return HireDetails(
    id: json['id'] as String?,
    hiredUser: json['hiredUser'] as String?,
    hiredUserId: json['hiredUserId'] as String?,
    hiredBy: json['hiredBy'] as String?,
    hiredById: json['hiredById'] as String?,
    isAccepted: json['isAccepted'] as bool?,
    isReacted: json['isReacted'] as bool?,
    jobTitle: json['jobTitle'] as String?,
    summary: json['summary'] as String?,
    rating: json['rating'] as String?,
    dateHired: json['dateHired'],
    dateUpdated: json['dateUpdated'],
    inProgress: json['inProgress'] as bool?,
    inCompleted: json['inCompleted'] as bool?,
  );
}

Map<String, dynamic> _$HireDetailsToJson(HireDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'hiredUser': instance.hiredUser,
      'hiredUserId': instance.hiredUserId,
      'hiredBy': instance.hiredBy,
      'hiredById': instance.hiredById,
      'jobTitle': instance.jobTitle,
      'summary': instance.summary,
      'rating': instance.rating,
      'dateHired': instance.dateHired,
      'dateUpdated': instance.dateUpdated,
      'isAccepted': instance.isAccepted,
      'isReacted': instance.isReacted,
      'inProgress': instance.inProgress,
      'inCompleted': instance.inCompleted,
    };
