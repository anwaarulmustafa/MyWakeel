// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'refer_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReferDetails _$ReferDetailsFromJson(Map json) {
  return ReferDetails(
    id: json['id'] as String?,
    refferedUser: json['refferedUser'] as String?,
    refferedUserId: json['refferedUserId'] as String?,
    refferedBy: json['refferedBy'] as String?,
    refferedById: json['refferedById'] as String?,
    isAccepted: json['isAccepted'] as bool?,
    isReacted: json['isReacted'] as bool?,
    dateReffered: json['dateReffered'],
    dateAccepted: json['dateAccepted'],
    refferedToId: json['refferedToId'] as String?,
    refferedTo: json['refferedTo'] as String?,
  );
}

Map<String, dynamic> _$ReferDetailsToJson(ReferDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'refferedUser': instance.refferedUser,
      'refferedUserId': instance.refferedUserId,
      'refferedBy': instance.refferedBy,
      'refferedById': instance.refferedById,
      'refferedTo': instance.refferedTo,
      'refferedToId': instance.refferedToId,
      'dateReffered': instance.dateReffered,
      'dateAccepted': instance.dateAccepted,
      'isAccepted': instance.isAccepted,
      'isReacted': instance.isReacted,
    };
