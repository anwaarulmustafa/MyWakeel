import 'package:json_annotation/json_annotation.dart';
part 'feed_details.g.dart';


@JsonSerializable(anyMap: true,)
class FeedDetails{

  String? id, posterName, posterId;
  String? posterImageUrl,  postText, postMedia;
  var date;
  bool? containsVideo, containsImage;
  int? noOfLikes, noOfComments;
  List<String>? likedBy;
  FeedDetails({this.id, this.postMedia, this.postText, this.likedBy, 
  this.posterId, this.posterImageUrl, this.posterName, 
  this.noOfLikes, this.noOfComments, this.containsImage, this.containsVideo, this.date});
  
    factory
  FeedDetails.fromJson(Map<String, dynamic> json)=>_$FeedDetailsFromJson(json);
  
  Map<String, dynamic> toJson()=>_$FeedDetailsToJson(this);

  //  Map<String, dynamic> createMap() {
  //   return {
  //     'id': id,
  //     'postMedia': postMedia,
  //     'postText': postText,
  //     'posterId': posterId,
  //     'posterImageUrl': posterImageUrl,
  //     'posterName': posterName,
  //     'noOfLikes': noOfLikes,
  //     'noOfComments': noOfComments,
  //     'containsImage': containsImage,
  //     'containsVideo': containsVideo,
  //     'date': date,
  //   };
  // }
  //  Map<String, dynamic> commentMap() {
  //   return {
  //     'id': id,
  //     'postMedia': postMedia,
  //     'postText': postText,
  //     'posterId': posterId,
  //     'posterImageUrl': posterImageUrl,
  //     'posterName': posterName,
  //     'date': date,
  //   };
  // }
  //  Map<String, dynamic> updateMap() {
  //   return {
     
      // 'noOfLikes': noOfLikes,
      // 'noOfComments': noOfComments,
  //   };
  // }

  // FeedDetails.fromSnap(Map fireStore)
  //     :
  //       id = fireStore['id'],
  //       postMedia = fireStore['postMedia'],
  //       postText = fireStore['postText'],
  //       posterId = fireStore['posterId'],
  //       posterImageUrl = fireStore['posterImageUrl'],
  //       posterName = fireStore['posterName'],
  //       noOfLikes = fireStore['noOfLikes'],
  //       containsImage = fireStore['containsImage'],
  //       containsVideo = fireStore['containsVideo'],
  //       date = fireStore['date'],
  //       noOfComments = fireStore['noOfComments'];
}