import 'package:mywakeel/models/follow_details.dart';

import 'certification_details.dart';
import 'experience_details.dart';
import 'package:json_annotation/json_annotation.dart';

import 'notifications_details.dart';
import 'follow_details.dart';

part 'user_details.g.dart';

@JsonSerializable(anyMap: true, explicitToJson: true)

class UserDetails{
  String?  name, imageUrl,uid, email, lat, long;
  String?  userType, gender,court, city;
  List<String>?  chats, hires, hired, reffered, referals, refferees, feeds;
  List<ExperienceDetails>? experience;
  List<CertificationsDetails>? cetifications;
  List<FollowDetails>? follows, followers;
  List<NotificationsDetails>? notifications;
  UserDetails({this.name, this.imageUrl, this.uid,
  this.email, this.userType,this.experience, this.lat, this.long,
   this.cetifications, this.gender,this.hires,this.hired,
   this.city, this.court, this.chats,this.referals,this.feeds, 
   this.followers, this.follows,
    this.reffered,this.refferees, this.notifications});
    factory
    UserDetails.fromJson(Map<String, dynamic> json)=>_$UserDetailsFromJson(json);
    
    Map<String, dynamic> toJson()=>_$UserDetailsToJson(this);

}