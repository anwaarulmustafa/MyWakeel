// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notifications_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NotificationsDetails _$NotificationsDetailsFromJson(Map json) {
  return NotificationsDetails(
    isRead: json['isRead'] as bool?,
    date: json['date'],
    id: json['id'] as String?,
    notificationId: json['notificationId'] as String?,
    notificationType: json['notificationType'] as String?,
  );
}

Map<String, dynamic> _$NotificationsDetailsToJson(
        NotificationsDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'notificationType': instance.notificationType,
      'notificationId': instance.notificationId,
      'date': instance.date,
      'isRead': instance.isRead,
    };
