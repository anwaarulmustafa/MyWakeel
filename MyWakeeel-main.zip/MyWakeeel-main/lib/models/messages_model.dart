class Message{
  String? type, message, time, senderId;
  Message({ this.message, this.time, this.senderId});
  
   Map<String, dynamic> createMap() {
    return {
      'time': time,
      'message': message,
      'type': type,
      'senderId': senderId,
      
    };
  }

  Message.fromSnap(Map fireStore)
      :
        time = fireStore['time'],
        message = fireStore['message'],
        type = fireStore['type'],
        senderId = fireStore['senderId'];
}