import 'package:json_annotation/json_annotation.dart';

part 'notifications_details.g.dart';

@JsonSerializable(anyMap: true,)
class NotificationsDetails{
  String? id,notificationType, notificationId; 
  var date;
  bool? isRead;
  NotificationsDetails({this.isRead, this.date, this.id,
   this.notificationId,this.notificationType});
  factory
    NotificationsDetails.fromJson(Map<String, dynamic> json)=>_$NotificationsDetailsFromJson(json);
    
    Map<String, dynamic> toJson()=>_$NotificationsDetailsToJson(this);
}