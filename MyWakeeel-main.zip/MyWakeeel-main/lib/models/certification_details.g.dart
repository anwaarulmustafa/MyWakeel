// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'certification_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CertificationsDetails _$CertificationsDetailsFromJson(Map json) {
  return CertificationsDetails(
    date: json['date'] as String?,
    title: json['title'] as String?,
  );
}

Map<String, dynamic> _$CertificationsDetailsToJson(
        CertificationsDetails instance) =>
    <String, dynamic>{
      'title': instance.title,
      'date': instance.date,
    };
