class MessageDetails{

  String? chatId, senderName, senderId;
  String? senderImageUrl;
  String?  recieverId, recentmessage, recentMessageTime;
  bool? isRead = false;
  MessageDetails({this.chatId, this.senderId, this.recentmessage, this.recieverId, 
  this.senderImageUrl, this.senderName, this.recentMessageTime, this.isRead});
  
   Map<String, dynamic> createMap() {
    return {
      'senderName': senderName,
      'senderId': senderId,
      'chatId': chatId,
      'senderImageUrl': senderImageUrl,
      'recieverId': recieverId,
      'recentmessage': recentmessage,
      'recentMessageTime': recentMessageTime,
      'isRead': isRead,
    };
  }
   Map<String, dynamic> updateMap() {
    return {
      'recentmessage': recentmessage,
      'recentMessageTime': recentMessageTime,
    };
  }

  MessageDetails.fromSnap(Map fireStore)
      :
        senderName = fireStore['senderName'],
        senderId = fireStore['senderId'],
        chatId = fireStore['chatId'],
        recentmessage = fireStore['recentmessage'],
        senderImageUrl = fireStore['senderImageUrl'],
        recieverId = fireStore['recieverId'],
        isRead = fireStore['isRead'],
        recentMessageTime = fireStore['recentMessageTime'];
}