// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'completed_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CompletedJobsDetails _$CompletedJobsDetailsFromJson(Map json) {
  return CompletedJobsDetails(
    clients: json['clients'] as String?,
    date: json['date'] as String?,
    jobTitle: json['jobTitle'] as String?,
    summary: json['summary'] as String?,
    status: json['status'] as String?,
    rating: json['rating'] as String?,
  );
}

Map<String, dynamic> _$CompletedJobsDetailsToJson(
        CompletedJobsDetails instance) =>
    <String, dynamic>{
      'jobTitle': instance.jobTitle,
      'clients': instance.clients,
      'date': instance.date,
      'summary': instance.summary,
      'status': instance.status,
      'rating': instance.rating,
    };
