import 'package:json_annotation/json_annotation.dart';

part 'refer_details.g.dart';
@JsonSerializable(anyMap: true,)
class ReferDetails{
  String? id, refferedUser, refferedUserId,
   refferedBy, refferedById,refferedTo, refferedToId;
  var dateReffered, dateAccepted;
   bool? isAccepted, isReacted;
  ReferDetails({this.id, this.refferedUser, this.refferedUserId, 
  this.refferedBy, this.refferedById, this.isAccepted,this.isReacted,
   this.dateReffered, this.dateAccepted, this.refferedToId, this.refferedTo});

  

  factory
  ReferDetails.fromJson(Map<String, dynamic> json)=>_$ReferDetailsFromJson(json);

  Map<String, dynamic> toJson()=>_$ReferDetailsToJson(this);

  
  //  Map<String, dynamic> createMap() {
  //   return {
  //     'id': id,
  //     'refferedUser': refferedUser,
  //     'refferedUserId': refferedUserId,
  //     'refferedBy': refferedBy,
  //     'refferedById': refferedById,
  //     'refferedTo': refferedTo,
  //     'refferedToId': refferedToId,
  //     'date': date,
  //     'isAccepted': isAccepted,
  //     'isRejected': isRejected,
  //   };
  // }
  

  // ReferDetails.fromSnap(Map fireStore)
  //     :
  //       id = fireStore['id'],
  //       refferedUser = fireStore['refferedUser'],
  //       refferedUserId = fireStore['refferedUserId'],
  //       refferedBy = fireStore['refferedBy'],
  //       refferedById = fireStore['refferedById'],
  //       refferedTo = fireStore['refferedTo'],
  //       isRejected = fireStore['isRejected'],
  //       isAccepted = fireStore['isAccepted'],
  //       date = fireStore['date'];

  
}