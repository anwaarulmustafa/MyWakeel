import 'package:json_annotation/json_annotation.dart';
part 'experience_details.g.dart';

@JsonSerializable(anyMap: true,)
class ExperienceDetails {
  String? jobTitle, clients, date, summary;
  ExperienceDetails({this.clients, this.date, this.jobTitle, this.summary});
   factory
  ExperienceDetails.fromJson(Map<String, dynamic> json)=>_$ExperienceDetailsFromJson(json);
  
  Map<String, dynamic> toJson()=>_$ExperienceDetailsToJson(this);

  
  
  //  Map<String, dynamic> createMap() {
  //   return {
  //     'jobTitle': jobTitle,
  //     'clients': clients,
  //     'date': date,
  //     'summary': summary,
  //   };
  // }

  // ExperienceDetails.fromSnap(Map fireStore)
  //     :
  //       jobTitle = fireStore['jobTitle'],
  //       clients = fireStore['clients'],
  //       date = fireStore['date'],
  //       summary= fireStore['summary'];

  // @override
  //   String toString() {
  //     return 'jobTitle: $jobTitle';
  //   }
}
