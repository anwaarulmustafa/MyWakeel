import 'package:json_annotation/json_annotation.dart';
part 'follow_details.g.dart';
@JsonSerializable(anyMap: true,)
class FollowDetails{
  String? name,uid, imageUrl;
  FollowDetails({this.name, this.uid, this.imageUrl});
  factory
  FollowDetails.fromJson(Map<String, dynamic> json)=>_$FollowDetailsFromJson(json);

  Map<String, dynamic> toJson()=>_$FollowDetailsToJson(this);


}